# Endless Road - live wallpaper (Android)

A calm van on a road that never ends.
- **Home screen:** small van, lots of empty sky, slow scenery. No clock, no battery, no charging effects.
- **Lock screen:** close cinematic camera, blurred scenery, a neon clock that doubles as the battery meter
  (green = on battery, blue = charging; rings light up at 20 / 50 / 80 / 100 %; amber under 15 %).
- Day and night follow the phone clock (8 colour moments, real moon phase), 7 landscapes (woods, cornfields,
  desert, mountains, coast, snow, tea gardens), optional random weather, no internet / location / sensors.

Works on Android 10+ (made for ZTE Blade A72s on Android 12 and Tecno Spark 40 on Android 15).

## Build the APK without a PC (GitHub does it for you)
1. Make a free GitHub account, create a **new empty repository** (private is fine).
2. In the repo: **Add file > Upload files**, upload `EndlessRoad.zip` (the zip itself, do not unzip). Commit.
3. **Add file > Create new file**, name it `.github/workflows/build-apk.yml` (typing the slashes makes the folders),
   paste the contents of `build-apk.yml`, commit.
4. Open the **Actions** tab. The build starts by itself (about 5-8 minutes). If it does not, pick "Build APK" > **Run workflow**.
5. When it is green, open the repo's **Releases** (right side). Download `EndlessRoad.apk` and open it on your phone
   (allow "install unknown apps" for your browser when asked).
6. Open **Endless Road**, tap **Set as wallpaper**, then **Set on home and lock screen**.

## Build with Android Studio (if you have a PC)
Open the `EndlessRoad` folder, let it sync, then **Build > Build APK(s)**. Or `gradle assembleRelease` with Gradle 8.9 and JDK 17.

## First run on your phones - what to look at
- In the wallpaper **preview, tap the screen**: home -> lock -> plugged in (van brakes, neon turns blue, rings light in sequence) -> full battery (sweep).
- Set your phone's own lock-screen clock to minimal/off so it does not overlap the neon clock.
- Tecno (Android 15): opening/closing apps should pull the camera back a little (needs the launcher to send wallpaper zoom; if nothing happens, tell me).
- ZTE (Android 12): no zoom signal, so returning to the home screen plays a short speed-up instead.
- Settings (app icon): smoothness, 12/24 h, battery %, weather, landscape, journey length, time of day (to preview night/dusk/sunrise any time), scene height.

## Layout of the code
`Scene.kt` simulation and drawing, `Biomes.kt` procedural landscapes, `Neon.kt` clock masks, `Van.kt` the van,
`Sky.kt` day/night palette, `RoadWallpaperService.kt` frame loop and phone signals, `SettingsActivity.kt`.
