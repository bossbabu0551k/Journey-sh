# Nothing special needed: the service and activity are kept by the manifest, no reflection on app classes.
-dontwarn **
