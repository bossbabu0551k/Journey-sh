package com.endlessroad.wallpaper

import kotlin.math.PI
import kotlin.math.sin

class SkyKey(
    val hour: Float,
    val top: Int,
    val mid: Int,
    val hor: Int,
    val ar: Float,
    val ag: Float,
    val ab: Float,
    val night: Float
)

/**
 * The look of the sky for a given hour. Eight colour moments (pre-dawn, sunrise, morning, noon,
 * afternoon, golden hour, dusk, night); each has sky top / middle / horizon colours, an ambient
 * light tint for the land, and a darkness value.
 */
class Sky {
    companion object {
        private fun k(h: Float, top: Int, mid: Int, hor: Int, ar: Float, ag: Float, ab: Float, n: Float): SkyKey =
            SkyKey(h, U.rgb(top), U.rgb(mid), U.rgb(hor), ar, ag, ab, n)

        val KEYS: Array<SkyKey> = arrayOf(
            k(0.0f, 0x060B1F, 0x0B1533, 0x1B2B55, 0.30f, 0.36f, 0.60f, 1.00f),
            k(5.0f, 0x121A44, 0x46477F, 0xE59A8E, 0.50f, 0.52f, 0.74f, 0.75f),
            k(6.5f, 0x3F6AB0, 0xF0B49A, 0xFFD08A, 1.00f, 0.84f, 0.72f, 0.15f),
            k(9.0f, 0x4C9BE8, 0x8CC8F2, 0xCFEAF6, 1.00f, 0.98f, 0.93f, 0.00f),
            k(12.5f, 0x2E86DE, 0x6DB9F0, 0xBFE4F6, 1.00f, 1.00f, 1.00f, 0.00f),
            k(15.5f, 0x3F8FDC, 0x86BEE8, 0xE4EDEA, 1.00f, 0.97f, 0.90f, 0.00f),
            k(17.5f, 0x4A78C2, 0xF3B27A, 0xFFD79A, 1.00f, 0.84f, 0.66f, 0.10f),
            k(19.0f, 0x2B2F6B, 0x8A4F8C, 0xF08A6A, 0.66f, 0.58f, 0.78f, 0.55f),
            k(21.0f, 0x060B1F, 0x0B1533, 0x1B2B55, 0.30f, 0.36f, 0.60f, 1.00f),
            k(24.0f, 0x060B1F, 0x0B1533, 0x1B2B55, 0.30f, 0.36f, 0.60f, 1.00f)
        )

        const val SYNODIC = 29.530588853

        fun phaseOf(nowMs: Long): Float {
            // New moon reference: 2000-01-06 18:14 UTC
            val days = (nowMs / 1000.0 - 947182440.0) / 86400.0
            var p = (days % SYNODIC) / SYNODIC
            if (p < 0.0) p += 1.0
            return p.toFloat()
        }
    }

    var top = 0
    var mid = 0
    var hor = 0
    var ar = 1f
    var ag = 1f
    var ab = 1f

    /** 0 = bright day, 1 = deep night. */
    var night = 0f

    /** 1 in full daylight, 0 at night. */
    var day = 1f

    /** Star visibility 0..1. */
    var stars = 0f

    /** Lamps, windows and headlights: 0 off .. 1 fully on. */
    var lamp = 0f

    /** Position along the sun's arc (0..1) and visibility. */
    var sunU = 0f
    var sunAlpha = 0f
    var sunArc = 0f
    var sunColor = 0

    var moonU = 0f
    var moonAlpha = 0f
    var moonPhase = 0.5f

    fun update(hour: Float, nowMs: Long) {
        var i = 0
        while (i < KEYS.size - 2 && hour > KEYS[i + 1].hour) i++
        val a = KEYS[i]
        val b = KEYS[i + 1]
        val t = U.smooth((hour - a.hour) / (b.hour - a.hour))
        top = U.mix(a.top, b.top, t)
        mid = U.mix(a.mid, b.mid, t)
        hor = U.mix(a.hor, b.hor, t)
        ar = U.lerp(a.ar, b.ar, t)
        ag = U.lerp(a.ag, b.ag, t)
        ab = U.lerp(a.ab, b.ab, t)
        night = U.lerp(a.night, b.night, t)
        day = 1f - U.ramp(0.15f, 0.85f, night)
        stars = U.ramp(0.45f, 0.85f, night)
        lamp = U.ramp(0.30f, 0.65f, night)

        // Sun: visible from about 05:55 to 18:50
        sunU = (hour - 5.9f) / 12.9f
        sunAlpha = U.ramp(5.6f, 6.3f, hour) * (1f - U.ramp(18.3f, 19.0f, hour))
        val uu = U.clamp01(sunU)
        sunArc = sin(PI.toFloat() * uu)
        sunColor = U.mix(U.rgb(0xFFB347), U.rgb(0xFFF6D8), U.smooth(sunArc / 0.4f))

        // Moon: visible from about 18:20 to 06:30
        val hh = ((hour - 18.2f) % 24f + 24f) % 24f
        moonU = hh / 12.4f
        moonAlpha = U.ramp(0f, 0.5f, hh) * (1f - U.ramp(11.6f, 12.4f, hh))
        moonPhase = phaseOf(nowMs)
    }
}
