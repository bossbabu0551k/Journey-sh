package com.endlessroad.wallpaper

import java.util.Random
import kotlin.math.abs
import kotlin.math.floor

/** Small math / colour helpers. Everything is Float and allocation-free. */
object U {
    fun clamp01(x: Float): Float = if (x < 0f) 0f else if (x > 1f) 1f else x

    fun clamp(x: Float, lo: Float, hi: Float): Float = if (x < lo) lo else if (x > hi) hi else x

    fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    fun smooth(x: Float): Float {
        val t = clamp01(x)
        return t * t * (3f - 2f * t)
    }

    fun smoother(x: Float): Float {
        val t = clamp01(x)
        return t * t * t * (t * (t * 6f - 15f) + 10f)
    }

    /** 0 below a, 1 above b, linear between. */
    fun ramp(a: Float, b: Float, x: Float): Float = clamp01((x - a) / (b - a))

    // ---- colours (ARGB ints) ----
    fun rgb(hex: Int): Int = hex or (0xFF shl 24)

    fun red(c: Int): Int = (c shr 16) and 0xFF
    fun green(c: Int): Int = (c shr 8) and 0xFF
    fun blue(c: Int): Int = c and 0xFF

    fun clampI(v: Int): Int = if (v < 0) 0 else if (v > 255) 255 else v

    fun mix(a: Int, b: Int, t: Float): Int {
        val k = clamp01(t)
        val r = (red(a) + (red(b) - red(a)) * k).toInt()
        val g = (green(a) + (green(b) - green(a)) * k).toInt()
        val bl = (blue(a) + (blue(b) - blue(a)) * k).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    fun mul(c: Int, mr: Float, mg: Float, mb: Float): Int {
        val r = clampI((red(c) * mr).toInt())
        val g = clampI((green(c) * mg).toInt())
        val b = clampI((blue(c) * mb).toInt())
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    /** Same RGB, alpha = a (0..1). */
    fun withAlpha(c: Int, a: Float): Int {
        val aa = clampI((a * 255f).toInt())
        return (aa shl 24) or (c and 0x00FFFFFF)
    }

    /** Local hour of day (0..24) for an epoch millisecond value. */
    fun localHour(nowMs: Long): Float {
        val off = java.util.TimeZone.getDefault().getOffset(nowMs)
        val sec = (((nowMs + off) / 1000L) % 86400L + 86400L) % 86400L
        return sec / 3600f
    }

    /** Positive modulo for doubles. */
    fun fmod(x: Double, m: Double): Double {
        val r = x % m
        return if (r < 0.0) r + m else r
    }
}

/** 1-D value noise that repeats every `period` lattice cells (so tiles wrap seamlessly). */
class PNoise(seed: Int, val period: Int) {
    private val v = FloatArray(period)

    init {
        val rnd = Random(seed.toLong())
        for (i in 0 until period) v[i] = rnd.nextFloat()
    }

    fun at(x: Float): Float {
        val xf = floor(x)
        val xi = xf.toInt()
        val t = x - xf
        val i0 = ((xi % period) + period) % period
        val i1 = (i0 + 1) % period
        val u = t * t * (3f - 2f * t)
        return v[i0] * (1f - u) + v[i1] * u
    }
}

/** Multi-octave periodic noise; `u` is the position across the tile in 0..1. */
class Terrain(seed: Int, cycles: Int, octaves: Int) {
    private val ns: Array<PNoise> = Array(octaves) { o -> PNoise(seed * 131 + o * 7, cycles * (1 shl o)) }
    private val amps: FloatArray = FloatArray(octaves) { o -> 1f / (1 shl o) }
    private val tot: Float

    init {
        var t = 0f
        for (a in amps) t += a
        tot = t
    }

    fun v(u: Float): Float {
        var t = 0f
        for (i in ns.indices) t += amps[i] * ns[i].at(u * ns[i].period)
        return t / tot
    }

    fun ridged(u: Float): Float = 1f - abs(2f * v(u) - 1f)
}
