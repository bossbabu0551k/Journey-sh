package com.endlessroad.wallpaper

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * The finished masks for one clock text ("9:41"). Ring 0 is the base outline of the digits, rings 1-3
 * are concentric contours around it. Each ring has a crisp core mask plus two soft glow masks
 * (stored at half resolution; drawing them scaled up gives a smooth bloom).
 */
class NeonMasks(
    val text: String,
    val unit: Float,
    val wPx: Int,
    val hPx: Int,
    /** Distance from the top of the bitmap to the bottom edge of the base outline. */
    val baseBottomPx: Float,
    val core: Array<Bitmap>,
    val glow: Array<Bitmap>,
    val halo: Array<Bitmap>
)

object Neon {
    private const val BW = 56f      // digit centre-line box width (units)
    private const val BH = 96f      // digit centre-line box height
    private const val SW = 17f      // tube thickness
    private const val GAP = 24f     // gap between digits
    private const val BAND = 3f     // thickness of an outline line
    private val OFFS = floatArrayOf(0f, 13f, 26f, 39f)
    private const val RING_EXT = 40.5f
    private const val PAD = 46f

    /** Width of the widest possible time ("00:00") in units, rings included. */
    fun referenceWidthUnits(): Float {
        return layoutWidth("00:00") + 2f * RING_EXT
    }

    fun referenceHeightUnits(): Float = BH + SW + 2f * RING_EXT

    /** Height of the digit tubes themselves (without rings), in units. */
    fun digitHeightUnits(): Float = BH + SW

    /** How far the outermost ring reaches beyond the digit edge, in units. */
    fun ringExtUnits(): Float = RING_EXT

    private fun layoutWidth(text: String): Float {
        var x = 0f
        for (ch in text) {
            x += if (ch == ':') SW + GAP * 0.9f else BW + SW + GAP
        }
        return x - GAP
    }

    private fun addDigit(p: Path, d: Int, ox: Float, oy: Float, rf: RectF) {
        val w = BW
        val h = BH
        when (d) {
            0 -> {
                p.addRoundRect(ox, oy, ox + w, oy + h, w / 2f, w / 2f, Path.Direction.CW)
            }
            1 -> {
                p.moveTo(ox + w * 0.18f, oy + h * 0.20f)
                p.lineTo(ox + w * 0.62f, oy)
                p.lineTo(ox + w * 0.62f, oy + h)
            }
            2 -> {
                p.moveTo(ox, oy + w / 2f)
                rf.set(ox, oy, ox + w, oy + w)
                p.arcTo(rf, 180f, 200f, false)
                p.lineTo(ox, oy + h)
                p.lineTo(ox + w, oy + h)
            }
            3 -> {
                rf.set(ox + w * 0.08f, oy, ox + w * 0.92f, oy + h / 2f)
                p.arcTo(rf, 205f, 245f, true)
                rf.set(ox, oy + h / 2f - 1f, ox + w, oy + h)
                p.arcTo(rf, 270f, 250f, false)
            }
            4 -> {
                p.moveTo(ox + w * 0.78f, oy + h)
                p.lineTo(ox + w * 0.78f, oy)
                p.lineTo(ox, oy + h * 0.70f)
                p.lineTo(ox + w, oy + h * 0.70f)
            }
            5 -> {
                p.moveTo(ox + w * 0.94f, oy)
                p.lineTo(ox + w * 0.10f, oy)
                p.lineTo(ox + w * 0.06f, oy + h * 0.46f)
                rf.set(ox, oy + h * 0.40f, ox + w, oy + h)
                p.arcTo(rf, 222f, 288f, false)
            }
            6 -> {
                p.moveTo(ox + w * 0.88f, oy + h * 0.05f)
                p.quadTo(ox, oy + h * 0.10f, ox, oy + h * 0.64f)
                p.addOval(ox, oy + h * 0.40f, ox + w, oy + h, Path.Direction.CW)
            }
            7 -> {
                p.moveTo(ox, oy)
                p.lineTo(ox + w, oy)
                p.lineTo(ox + w * 0.30f, oy + h)
            }
            8 -> {
                p.addOval(ox + w * 0.08f, oy, ox + w * 0.92f, oy + h * 0.50f, Path.Direction.CW)
                p.addOval(ox, oy + h * 0.47f, ox + w, oy + h, Path.Direction.CW)
            }
            else -> {
                p.moveTo(ox + w * 0.12f, oy + h * 0.95f)
                p.quadTo(ox + w, oy + h * 0.90f, ox + w, oy + h * 0.36f)
                p.addOval(ox, oy, ox + w, oy + h * 0.60f, Path.Direction.CW)
            }
        }
    }

    private fun addColon(p: Path, ox: Float, oy: Float) {
        // a zero-length line with round caps draws a dot
        p.moveTo(ox, oy + BH * 0.30f)
        p.lineTo(ox + 0.01f, oy + BH * 0.30f)
        p.moveTo(ox, oy + BH * 0.70f)
        p.lineTo(ox + 0.01f, oy + BH * 0.70f)
    }

    private fun buildPath(text: String): Path {
        val p = Path()
        val rf = RectF()
        var x = 0f
        for (ch in text) {
            if (ch == ':') {
                addColon(p, x + SW / 2f, SW / 2f)
                x += SW + GAP * 0.9f
            } else {
                val d = ch - '0'
                if (d in 0..9) addDigit(p, d, x + SW / 2f, SW / 2f, rf)
                x += BW + SW + GAP
            }
        }
        return p
    }

    private fun renderRing(src: Path, k: Int, w: Int, h: Int, scale: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
        val c = Canvas(bmp)
        c.scale(scale, scale)
        c.translate(PAD, PAD)

        val ink = Paint(Paint.ANTI_ALIAS_FLAG)
        ink.style = Paint.Style.STROKE
        ink.strokeCap = Paint.Cap.ROUND
        ink.strokeJoin = Paint.Join.ROUND
        val o = OFFS[k]
        ink.strokeWidth = SW + 2f * (o + BAND / 2f)
        c.drawPath(src, ink)

        val wi = SW + 2f * (o - BAND / 2f)
        if (wi > 0f) {
            val eraser = Paint(Paint.ANTI_ALIAS_FLAG)
            eraser.style = Paint.Style.STROKE
            eraser.strokeCap = Paint.Cap.ROUND
            eraser.strokeJoin = Paint.Join.ROUND
            eraser.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            eraser.strokeWidth = wi
            c.drawPath(src, eraser)
        }
        return bmp
    }

    /** Builds all masks for `text`. `unit` = pixels per design unit. Call from a background thread. */
    fun render(text: String, unit: Float): NeonMasks {
        val path = buildPath(text)
        val total = layoutWidth(text)
        val wPx = ((total + 2f * PAD) * unit).toInt() + 2
        val hPx = ((BH + SW + 2f * PAD) * unit).toInt() + 2
        val hw = (wPx + 1) / 2
        val hh = (hPx + 1) / 2

        val core = ArrayList<Bitmap>()
        val glow = ArrayList<Bitmap>()
        val halo = ArrayList<Bitmap>()
        val r1 = max(1, (2f * unit).roundToInt())
        val r2 = max(2, (7f * unit).roundToInt())
        for (k in 0 until 4) {
            core.add(renderRing(path, k, wPx, hPx, unit))
            val g = renderRing(path, k, hw, hh, unit * 0.5f)
            val hl = renderRing(path, k, hw, hh, unit * 0.5f)
            blur(g, r1, 3, 2.4f)
            blur(hl, r2, 3, 3.2f)
            glow.add(g)
            halo.add(hl)
        }
        return NeonMasks(
            text, unit, wPx, hPx, (PAD + BH + SW) * unit,
            core.toTypedArray(), glow.toTypedArray(), halo.toTypedArray()
        )
    }

    // ---- box blur on an ALPHA_8 bitmap ----
    private fun blur(bmp: Bitmap, r: Int, passes: Int, gain: Float) {
        val w = bmp.width
        val h = bmp.height
        val stride = bmp.rowBytes
        val buf = ByteBuffer.allocate(bmp.byteCount)
        bmp.copyPixelsToBuffer(buf)
        val a = buf.array()
        val b = ByteArray(a.size)
        for (i in 0 until passes) {
            blurH(a, b, w, h, stride, r)
            blurV(b, a, w, h, stride, r)
        }
        for (y in 0 until h) {
            val row = y * stride
            for (x in 0 until w) {
                val v = ((a[row + x].toInt() and 0xFF) * gain).toInt()
                a[row + x] = (if (v > 255) 255 else v).toByte()
            }
        }
        buf.rewind()
        bmp.copyPixelsFromBuffer(buf)
    }

    private fun blurH(src: ByteArray, dst: ByteArray, w: Int, h: Int, stride: Int, r: Int) {
        val n = 2 * r + 1
        for (y in 0 until h) {
            val row = y * stride
            var sum = 0
            for (x in 0..r) {
                if (x < w) sum += src[row + x].toInt() and 0xFF
            }
            for (x in 0 until w) {
                dst[row + x] = (sum / n).toByte()
                val addX = x + r + 1
                val subX = x - r
                if (addX < w) sum += src[row + addX].toInt() and 0xFF
                if (subX >= 0) sum -= src[row + subX].toInt() and 0xFF
            }
        }
    }

    private fun blurV(src: ByteArray, dst: ByteArray, w: Int, h: Int, stride: Int, r: Int) {
        val n = 2 * r + 1
        for (x in 0 until w) {
            var sum = 0
            for (y in 0..r) {
                if (y < h) sum += src[y * stride + x].toInt() and 0xFF
            }
            for (y in 0 until h) {
                dst[y * stride + x] = (sum / n).toByte()
                val addY = y + r + 1
                val subY = y - r
                if (addY < h) sum += src[addY * stride + x].toInt() and 0xFF
                if (subY >= 0) sum -= src[subY * stride + x].toInt() and 0xFF
            }
        }
    }
}
