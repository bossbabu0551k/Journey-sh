package com.endlessroad.wallpaper

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.sin

/** Everything the van needs to know to draw itself for one frame. */
class VanState {
    /** Ground contact point (screen px) of the middle of the van. */
    var x = 0f
    var y = 0f

    /** Pixels per design unit. */
    var scale = 1f
    var wheelDeg = 0f

    /** Nose-down is positive. */
    var pitchDeg = 0f
    var bob = 0f

    /** 0 = daylight, 1 = lights on. */
    var lamp = 0f

    /** 0 = home (plain), 1 = lock (dog, mug, string lights...). */
    var detail = 0f
    var time = 0f
}

/**
 * A retro camper van drawn from paths, in "design units": 210 long, ground at y = 0, up is negative,
 * facing right. Close-up details (dog, steaming mug, string lights, roof vent) fade in with `detail`.
 */
class VanRenderer {
    companion object {
        const val LENGTH = 210f
        const val GEAR_TOP = -118f
        const val ROOF = -94f
        const val WHEEL_R = 18f
        const val WHEEL_Y = -18f

        private val BODY = U.rgb(0xE0663F)
        private val CREAM = U.rgb(0xF3E7CD)
        private val DARK = U.rgb(0x2B2A33)
        private val TRIM = U.rgb(0xB24A2B)
        private val FRAME = U.rgb(0x3A3F4A)
        private val ROOF_TRIM = U.rgb(0xE6D7B6)
        private val GLASS_DAY = U.rgb(0x9FD0E6)
        private val GLASS_NIGHT = U.rgb(0xFFD48A)
        private val TIRE = U.rgb(0x1B1B20)
        private val RIM = U.rgb(0xD9D5C8)
        private val HUB = U.rgb(0x6E6B66)
        private val TEAL = U.rgb(0x3FA7A0)
        private val AMBER = U.rgb(0xE9A23B)
        private val WHEELS = floatArrayOf(-62f, 62f)
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val beamPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tmp = Path()
    private val rf = RectF()

    private val body = Path()
    private val lowerBand = Path()
    private val board = Path()
    private val beam = Path()
    private val frames = ArrayList<Path>()
    private val glass = ArrayList<Path>()
    private val stripes = ArrayList<Path>()

    init {
        fill.style = Paint.Style.FILL
        stroke.style = Paint.Style.STROKE
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.strokeJoin = Paint.Join.ROUND

        body.moveTo(-104f, -24f)
        body.lineTo(-104f, -76f)
        body.quadTo(-104f, -94f, -86f, -94f)
        body.lineTo(66f, -94f)
        body.quadTo(84f, -94f, 91f, -78f)
        body.lineTo(101f, -50f)
        body.quadTo(106f, -36f, 103f, -24f)
        body.close()

        lowerBand.moveTo(-104f, -24f)
        lowerBand.lineTo(-104f, -46f)
        lowerBand.lineTo(98f, -46f)
        lowerBand.lineTo(101f, -50f)
        lowerBand.quadTo(106f, -36f, 103f, -24f)
        lowerBand.close()

        board.moveTo(-76f, -105f)
        board.quadTo(-80f, -108f, -70f, -109f)
        board.lineTo(30f, -109f)
        board.quadTo(52f, -107f, 56f, -104.5f)
        board.quadTo(44f, -102f, 30f, -102f)
        board.lineTo(-70f, -102f)
        board.quadTo(-78f, -102f, -76f, -105f)
        board.close()

        beam.moveTo(101f, -44f)
        beam.lineTo(262f, -62f)
        beam.lineTo(262f, 2f)
        beam.lineTo(101f, -36f)
        beam.close()
        beamPaint.style = Paint.Style.FILL
        beamPaint.shader = LinearGradient(
            101f, 0f, 262f, 0f,
            U.withAlpha(0xFFF1C4, 0.55f), U.withAlpha(0xFFF1C4, 0f), Shader.TileMode.CLAMP
        )

        // windows: rear, three side windows, cab window
        addWindow(-97f, -86f, -80f, -58f)
        addWindow(-74f, -86f, -44f, -58f)
        addWindow(-38f, -86f, -8f, -58f)
        addWindow(-2f, -86f, 30f, -58f)
        val cab = Path()
        cab.moveTo(40f, -86f)
        cab.lineTo(70f, -86f)
        cab.quadTo(82f, -86f, 86f, -76f)
        cab.lineTo(93f, -58f)
        cab.lineTo(40f, -58f)
        cab.close()
        registerWindow(cab)
    }

    private fun addWindow(l: Float, t: Float, r: Float, b: Float) {
        val p = Path()
        p.addRoundRect(l, t, r, b, 5f, 5f, Path.Direction.CW)
        registerWindow(p)
    }

    private fun registerWindow(frame: Path) {
        val bounds = RectF()
        frame.computeBounds(bounds, true)
        val cx = bounds.centerX()
        val cy = bounds.centerY()
        val m = Matrix()
        m.setScale(0.90f, 0.88f, cx, cy)
        val g = Path()
        frame.transform(m, g)
        val w = bounds.width()
        val l = bounds.left
        val t = bounds.top
        val b = bounds.bottom
        val s = Path()
        s.moveTo(l + 0.34f * w, t + 2f)
        s.lineTo(l + 0.58f * w, t + 2f)
        s.lineTo(l + 0.36f * w, b - 2f)
        s.lineTo(l + 0.12f * w, b - 2f)
        s.close()
        frames.add(frame)
        glass.add(g)
        stripes.add(s)
    }

    private fun line(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, wd: Float, col: Int) {
        stroke.color = col
        stroke.strokeWidth = wd
        c.drawLine(x0, y0, x1, y1, stroke)
    }

    fun draw(c: Canvas, s: VanState) {
        val lamp = s.lamp
        val det = s.detail
        val t = s.time

        c.save()
        c.translate(s.x, s.y)
        c.scale(s.scale, s.scale)

        // ground shadow
        fill.color = U.withAlpha(0x000000, 0.26f - 0.10f * lamp)
        c.drawOval(-100f, -4f, 104f, 5f, fill)

        // headlight beam on the road
        if (lamp > 0.02f) {
            beamPaint.alpha = (255f * lamp * 0.9f).toInt()
            c.drawPath(beam, beamPaint)
        }

        // ---- body (rides on the suspension) ----
        c.save()
        c.translate(0f, s.bob)
        c.rotate(s.pitchDeg, -62f, WHEEL_Y)

        fill.color = CREAM
        c.drawPath(body, fill)
        fill.color = BODY
        c.drawPath(lowerBand, fill)
        line(c, -104f, -46.5f, 99f, -46.5f, 2.2f, TRIM)
        line(c, -100f, -90f, 64f, -90f, 3.0f, ROOF_TRIM)

        // warm glow around the windows at night
        if (lamp > 0.02f) {
            for (p in frames) {
                stroke.color = U.withAlpha(0xFFC66E, 0.10f * lamp)
                stroke.strokeWidth = 8f
                c.drawPath(p, stroke)
                stroke.color = U.withAlpha(0xFFC66E, 0.16f * lamp)
                stroke.strokeWidth = 4f
                c.drawPath(p, stroke)
            }
        }

        val glassCol = U.mix(GLASS_DAY, GLASS_NIGHT, lamp)
        val reflect = U.withAlpha(0xFFFFFF, 0.28f * (1f - lamp))
        for (i in frames.indices) {
            fill.color = FRAME
            c.drawPath(frames[i], fill)
            fill.color = glassCol
            c.drawPath(glass[i], fill)
            if (lamp < 0.9f) {
                fill.color = reflect
                c.drawPath(stripes[i], fill)
            }
        }

        // door seams and handle
        line(c, 36f, -92f, 36f, -26f, 1.1f, TRIM)
        line(c, -44f, -92f, -44f, -26f, 1.1f, TRIM)
        line(c, -6f, -92f, -6f, -26f, 1.1f, TRIM)
        line(c, 26f, -52f, 32f, -52f, 2.0f, DARK)

        // bumpers
        fill.color = DARK
        c.drawRoundRect(-110f, -32f, -102f, -23f, 2f, 2f, fill)
        c.drawRoundRect(102f, -32f, 109f, -23f, 2f, 2f, fill)

        // lights
        if (lamp > 0.02f) {
            fill.color = U.withAlpha(0xFFF0B0, 0.22f * lamp)
            c.drawCircle(99f, -42f, 12f, fill)
            fill.color = U.withAlpha(0xFF3A30, 0.25f * lamp)
            c.drawCircle(-103f, -43f, 8f, fill)
        }
        fill.color = U.mix(U.rgb(0xF7F1DC), U.rgb(0xFFF6CC), lamp)
        c.drawCircle(99f, -42f, 5.2f, fill)
        fill.color = U.mix(U.rgb(0xD8332C), U.rgb(0xFF4A3D), lamp)
        c.drawRoundRect(-105f, -48f, -101f, -38f, 1.5f, 1.5f, fill)

        // wheel arches
        fill.color = DARK
        for (wx in WHEELS) c.drawCircle(wx, WHEEL_Y, 22f, fill)

        // roof rack, surfboard, duffel bag
        line(c, -72f, -95f, -72f, -101f, 1.6f, DARK)
        line(c, 40f, -95f, 40f, -101f, 1.6f, DARK)
        line(c, -72f, -101f, 40f, -101f, 1.6f, DARK)
        fill.color = TEAL
        c.drawPath(board, fill)
        line(c, -60f, -105.5f, 44f, -105.5f, 1.2f, CREAM)
        fill.color = AMBER
        c.drawRoundRect(-62f, -118f, -34f, -109f, 4f, 4f, fill)

        if (det > 0.02f) drawDetails(c, det, lamp, t)

        c.restore()

        // ---- wheels ----
        for (wx in WHEELS) {
            fill.color = TIRE
            c.drawCircle(wx, WHEEL_Y, WHEEL_R, fill)
            fill.color = RIM
            c.drawCircle(wx, WHEEL_Y, 10f, fill)
            stroke.color = HUB
            stroke.strokeWidth = 1.4f
            c.save()
            c.translate(wx, WHEEL_Y)
            c.rotate(s.wheelDeg)
            for (i in 0 until 5) {
                c.drawLine(0f, 0f, 8.6f, 0f, stroke)
                c.rotate(72f)
            }
            c.restore()
            fill.color = HUB
            c.drawCircle(wx, WHEEL_Y, 3.2f, fill)
        }

        c.restore()
    }

    private fun drawDetails(c: Canvas, det: Float, lamp: Float, t: Float) {
        // string lights along the roof edge
        val n = 14
        for (i in 0 until n) {
            val x = -86f + i * (150f / (n - 1))
            val y = -95.5f + (if (i % 2 == 1) 2.2f else 0f)
            val tw = 0.6f + 0.4f * sin(t * 3f + i * 1.7f)
            val a = det * (0.55f + 0.45f * lamp) * tw
            fill.color = U.withAlpha(0xFFDC8C, a)
            c.drawCircle(x, y, 1.3f, fill)
            if (lamp > 0.2f) {
                fill.color = U.withAlpha(0xFFD278, a * 0.16f * lamp)
                c.drawCircle(x, y, 3.2f, fill)
            }
        }

        // roof vent and its little puffs
        fill.color = U.withAlpha(0xCFC6AE, det)
        c.drawRoundRect(-14f, -99f, 4f, -94f, 1.5f, 1.5f, fill)
        for (i in 0 until 4) {
            val ph = (t * 0.6f + i * 0.25f) % 1f
            val r = 1.6f + 2.4f * ph
            val y = -100f - ph * 16f
            val x = -5f + 3f * sin(ph * 5f + i)
            fill.color = U.withAlpha(0xFFFFFF, 0.5f * (1f - ph) * det)
            c.drawCircle(x, y, r, fill)
        }

        // sleeping dog in the door window
        c.save()
        c.scale(1f, 1f + 0.025f * sin(t * 1.5f), 16f, -58f)
        fill.color = U.withAlpha(0x6B4A36, det)
        rf.set(8f, -72f, 24f, -58f)
        c.drawOval(rf, fill)
        fill.color = U.withAlpha(0x4A3223, det)
        tmp.reset()
        tmp.moveTo(10f, -71f)
        tmp.quadTo(4f, -68f, 6f, -60f)
        tmp.quadTo(12f, -62f, 14f, -68f)
        tmp.close()
        c.drawPath(tmp, fill)
        fill.color = U.withAlpha(0x8A6246, det)
        rf.set(18f, -66f, 28f, -59f)
        c.drawOval(rf, fill)
        fill.color = U.withAlpha(0x2B2A33, det)
        c.drawCircle(26.8f, -63.2f, 1.5f, fill)
        tmp.reset()
        tmp.moveTo(15f, -66f)
        tmp.quadTo(17f, -64.6f, 19f, -66f)
        stroke.color = U.withAlpha(0x2B2A33, det)
        stroke.strokeWidth = 0.9f
        c.drawPath(tmp, stroke)
        c.restore()

        // steaming mug in the cab window
        fill.color = U.withAlpha(0xF7F1E3, det)
        c.drawRoundRect(60f, -66f, 68f, -58.5f, 1.5f, 1.5f, fill)
        tmp.reset()
        tmp.moveTo(68f, -64.5f)
        tmp.quadTo(72f, -64f, 68f, -60.5f)
        stroke.color = U.withAlpha(0xF7F1E3, det)
        stroke.strokeWidth = 1.1f
        c.drawPath(tmp, stroke)
        for (k in 0 until 2) {
            val ph = (t * 0.5f + k * 0.5f) % 1f
            tmp.reset()
            tmp.moveTo(62f + k * 3.2f, -67f)
            for (j in 1..8) {
                val yy = -67f - j * 2.1f
                val xx = 62f + k * 3.2f + 2.0f * sin(ph * 6f + j * 0.9f + k)
                tmp.lineTo(xx, yy)
            }
            stroke.color = U.withAlpha(0xFFFFFF, 0.6f * det)
            stroke.strokeWidth = 0.9f
            c.drawPath(tmp, stroke)
        }
    }
}
