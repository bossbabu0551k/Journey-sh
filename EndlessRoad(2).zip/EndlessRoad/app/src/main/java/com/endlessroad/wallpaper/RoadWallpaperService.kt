package com.endlessroad.wallpaper

import android.app.KeyguardManager
import android.app.WallpaperColors
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.Choreographer
import android.view.Display
import android.view.MotionEvent
import android.view.SurfaceHolder
import kotlin.math.max
import kotlin.math.roundToInt

class RoadWallpaperService : WallpaperService() {

    companion object {
        private const val TAG = "EndlessRoad"
    }

    override fun onCreateEngine(): Engine = RoadEngine()

    private inner class RoadEngine : Engine() {
        private var scene: Scene? = null
        private var choreographer: Choreographer? = null
        private var keyguard: KeyguardManager? = null
        private var refresh = 60f

        private var visible = false
        private var running = false
        private var surfaceOk = false
        private var hiddenWhileInteractive = false
        private var lastLocked = false
        private var lastPollNs = 0L
        private var lastThemeKey = -1
        private var useHw = true
        private var errors = 0

        private val frameCb = Choreographer.FrameCallback { t -> onFrame(t) }

        private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            scene?.applySettings(Settings.load(applicationContext))
        }

        private val batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent != null) handleBattery(intent)
            }
        }

        private val screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val action = intent?.action ?: return
                if (action == Intent.ACTION_USER_PRESENT) {
                    if (!isPreview && visible && lastLocked) {
                        lastLocked = false
                        scene?.setLocked(false)
                    }
                } else if (action == Intent.ACTION_SCREEN_ON) {
                    pollKeyguard(true)
                }
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)
            val ctx = applicationContext
            val s = Scene(ctx)
            s.setPreview(isPreview)
            scene = s
            keyguard = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            choreographer = Choreographer.getInstance()
            refresh = readRefreshRate()
            setTouchEventsEnabled(isPreview)

            try {
                val sticky = registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                if (sticky != null) handleBattery(sticky)
            } catch (e: Exception) {
                Log.w(TAG, "battery receiver", e)
            }
            try {
                val f = IntentFilter()
                f.addAction(Intent.ACTION_SCREEN_ON)
                f.addAction(Intent.ACTION_USER_PRESENT)
                registerReceiver(screenReceiver, f)
            } catch (e: Exception) {
                Log.w(TAG, "screen receiver", e)
            }
            Settings.prefs(ctx).registerOnSharedPreferenceChangeListener(prefListener)
        }

        override fun onDestroy() {
            stopLoop()
            try {
                unregisterReceiver(batteryReceiver)
            } catch (e: Exception) {
            }
            try {
                unregisterReceiver(screenReceiver)
            } catch (e: Exception) {
            }
            Settings.prefs(applicationContext).unregisterOnSharedPreferenceChangeListener(prefListener)
            scene?.release()
            scene = null
            super.onDestroy()
        }

        private fun readRefreshRate(): Float {
            return try {
                val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
                val r = dm.getDisplay(Display.DEFAULT_DISPLAY).refreshRate
                if (r >= 30f && r <= 240f) r else 60f
            } catch (e: Exception) {
                60f
            }
        }

        private fun handleBattery(intent: Intent) {
            if (isPreview) return
            val lvl = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val chg = plugged != 0 ||
                status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (lvl >= 0 && scale > 0) {
                scene?.setBattery((lvl * 100f / scale).roundToInt(), chg)
            }
        }

        // ---------------------------------------------------------- lock detection

        private fun evalLocked(): Boolean {
            if (isPreview) return false
            return try {
                keyguard?.isKeyguardLocked ?: false
            } catch (e: Exception) {
                false
            }
        }

        private fun pollKeyguard(force: Boolean) {
            if (isPreview) return
            val now = System.nanoTime()
            if (!force && now - lastPollNs < 250_000_000L) return
            lastPollNs = now
            val l = evalLocked()
            if (l != lastLocked) {
                lastLocked = l
                if (visible) scene?.setLocked(l)
            }
        }

        // ---------------------------------------------------------- lifecycle

        override fun onVisibilityChanged(v: Boolean) {
            super.onVisibilityChanged(v)
            visible = v
            val s = scene ?: return
            if (v) {
                errors = 0
                val locked = evalLocked()
                lastLocked = locked
                lastPollNs = System.nanoTime()
                s.onShow(locked, hiddenWhileInteractive)
                if (surfaceOk) startLoop()
            } else {
                hiddenWhileInteractive = try {
                    (getSystemService(Context.POWER_SERVICE) as? PowerManager)?.isInteractive ?: false
                } catch (e: Exception) {
                    false
                }
                stopLoop()
                s.onHide()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceOk = true
            scene?.resize(width, height)
            if (visible) startLoop()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            surfaceOk = false
            stopLoop()
            super.onSurfaceDestroyed(holder)
        }

        override fun onTouchEvent(event: MotionEvent?) {
            if (isPreview && event != null && event.action == MotionEvent.ACTION_UP) {
                scene?.demoNext()
            }
            super.onTouchEvent(event)
        }

        /** The launcher / system UI pushes the wallpaper away while an app opens (0 = near, 1 = far). */
        override fun onZoomChanged(zoom: Float) {
            super.onZoomChanged(zoom)
            scene?.onZoom(zoom)
        }

        override fun onComputeColors(): WallpaperColors? {
            val s = scene ?: return null
            return try {
                val c = s.themeColors()
                WallpaperColors(Color.valueOf(c[0]), Color.valueOf(c[1]), Color.valueOf(c[2]))
            } catch (e: Exception) {
                null
            }
        }

        // ---------------------------------------------------------- frame loop

        private fun startLoop() {
            if (running) return
            running = true
            choreographer?.postFrameCallback(frameCb)
        }

        private fun stopLoop() {
            running = false
            choreographer?.removeFrameCallback(frameCb)
        }

        private fun onFrame(frameNanos: Long) {
            if (!running) return
            if (!visible || !surfaceOk) {
                running = false
                return
            }
            pollKeyguard(false)
            drawFrame(frameNanos)
            if (!running) return
            val s = scene ?: return

            val key = s.themeKey()
            if (key != lastThemeKey) {
                lastThemeKey = key
                try {
                    notifyColorsChanged()
                } catch (e: Exception) {
                }
            }

            // Pace frames to a whole number of display refreshes (e.g. every 4th vsync on 120 Hz = 30 fps)
            val fps = max(1f, s.desiredFps())
            val vsyncNs = 1.0e9 / refresh
            val k = max(1, (refresh / fps).roundToInt())
            val targetNs = frameNanos + (k * vsyncNs).toLong() - (vsyncNs * 0.5).toLong()
            val delayMs = (targetNs - System.nanoTime()) / 1_000_000L
            if (delayMs > 1L) {
                choreographer?.postFrameCallbackDelayed(frameCb, delayMs)
            } else {
                choreographer?.postFrameCallback(frameCb)
            }
        }

        private fun drawFrame(frameNanos: Long) {
            val s = scene ?: return
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = if (useHw && Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas() else holder.lockCanvas()
                if (canvas != null) s.frame(frameNanos, canvas)
                errors = 0
            } catch (t: Throwable) {
                errors++
                if (useHw && errors >= 2) useHw = false
                Log.w(TAG, "frame failed", t)
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Throwable) {
                    }
                }
            }
            // never crash-loop: if drawing keeps failing, stop quietly until the next wake-up
            if (errors >= 12) stopLoop()
        }
    }
}
