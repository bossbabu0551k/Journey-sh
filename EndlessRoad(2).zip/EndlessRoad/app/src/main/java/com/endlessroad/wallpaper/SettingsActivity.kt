package com.endlessroad.wallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Plain-view settings screen. Changes are saved instantly and picked up live by the wallpaper. */
class SettingsActivity : Activity() {

    private var density = 1f

    private fun dp(v: Int): Int = (v * density).toInt()

    private fun label(text: String, sp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(11, 18, 38))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(36), dp(22), dp(40))
        scroll.addView(col)

        val white = Color.rgb(240, 244, 255)
        val soft = Color.rgb(160, 172, 205)
        val green = Color.rgb(120, 255, 154)

        col.addView(label("Endless Road", 30f, green, true))
        val sub = label("A calm van on a road that never ends. Home stays quiet; the lock screen turns into a neon clock that doubles as your battery meter.", 14f, soft, false)
        sub.setPadding(0, dp(6), 0, dp(18))
        col.addView(sub)

        val setBtn = Button(this)
        setBtn.text = "Set as wallpaper"
        setBtn.setOnClickListener { launchPicker() }
        col.addView(setBtn)

        val tip = label(
            "Tip: on the lock screen, set your phone's own clock style to minimal or off, so it does not sit on top of the neon clock. " +
                "In the wallpaper preview, tap the screen to try lock, charging and full-battery looks.",
            13f, soft, false
        )
        tip.setPadding(0, dp(14), 0, dp(10))
        col.addView(tip)

        val prefs = Settings.prefs(this)

        for (opt in Settings.OPTIONS) {
            val h = label(opt.title, 17f, white, true)
            h.setPadding(0, dp(22), 0, dp(6))
            col.addView(h)

            val group = RadioGroup(this)
            group.orientation = RadioGroup.VERTICAL
            val current = prefs.getInt(opt.key, opt.def)
            for (i in opt.labels.indices) {
                val rb = RadioButton(this)
                rb.id = View.generateViewId()
                rb.text = opt.labels[i]
                rb.setTextColor(white)
                rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                rb.isChecked = (i == current)
                val choice = i
                val key = opt.key
                rb.setOnCheckedChangeListener { _, checked ->
                    if (checked) prefs.edit().putInt(key, choice).apply()
                }
                group.addView(rb)
            }
            col.addView(group)
        }

        val veh = label("Vehicle", 17f, white, true)
        veh.setPadding(0, dp(22), 0, dp(6))
        col.addView(veh)
        col.addView(label("Camper van (more vehicles are on the way)", 15f, soft, false))

        val foot = label("No internet, location or sensor permissions are used. Weather is random and made up on the phone.", 12f, soft, false)
        foot.gravity = Gravity.START
        foot.setPadding(0, dp(28), 0, 0)
        col.addView(foot)

        setContentView(scroll)
    }

    private fun launchPicker() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, RoadWallpaperService::class.java)
            )
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                Toast.makeText(this, "Open your wallpaper settings and choose Endless Road", Toast.LENGTH_LONG).show()
            }
        }
    }
}
