package com.endlessroad.wallpaper

import android.content.Context
import android.content.SharedPreferences

/** All user options. Stored as small ints in SharedPreferences. */
object Settings {
    const val PREFS = "endless_road"

    const val K_FPS = "fps"
    const val K_TIME_FORMAT = "time_format"
    const val K_WEATHER = "weather"
    const val K_BIOME = "biome"
    const val K_PACE = "pace"
    const val K_TIME_OVERRIDE = "time_override"
    const val K_ROAD_POS = "road_pos"
    const val K_SHOW_PERCENT = "show_percent"
    const val K_VEHICLE = "vehicle"

    // Journey memory (not a user option)
    const val K_J_BIOME = "j_biome"
    const val K_J_TIME = "j_time"

    class Snap(
        /** 0 eco, 1 balanced, 2 smooth */
        val fps: Int,
        /** 0 follow phone, 1 12-hour, 2 24-hour */
        val timeFormat: Int,
        /** 0 off, 1 occasional */
        val weather: Int,
        /** 0 = journey through all biomes, 1..7 = stay in one biome */
        val biome: Int,
        /** 0 short, 1 normal, 2 long biome length */
        val pace: Int,
        /** 0 follow phone clock, 1..5 fixed time of day */
        val timeOverride: Int,
        /** 0 higher, 1 default, 2 lower */
        val roadPos: Int,
        val showPercent: Boolean,
        val vehicle: Int
    )

    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(ctx: Context): Snap {
        val p = prefs(ctx)
        return Snap(
            fps = p.getInt(K_FPS, 1),
            timeFormat = p.getInt(K_TIME_FORMAT, 0),
            weather = p.getInt(K_WEATHER, 1),
            biome = p.getInt(K_BIOME, 0),
            pace = p.getInt(K_PACE, 1),
            timeOverride = p.getInt(K_TIME_OVERRIDE, 0),
            roadPos = p.getInt(K_ROAD_POS, 1),
            showPercent = p.getInt(K_SHOW_PERCENT, 0) == 1,
            vehicle = p.getInt(K_VEHICLE, 0)
        )
    }

    fun loadJourneyBiome(ctx: Context): Int = prefs(ctx).getInt(K_J_BIOME, 0)

    fun loadJourneyTime(ctx: Context): Float = prefs(ctx).getFloat(K_J_TIME, 0f)

    fun saveJourney(ctx: Context, biomeId: Int, seconds: Float) {
        prefs(ctx).edit().putInt(K_J_BIOME, biomeId).putFloat(K_J_TIME, seconds).apply()
    }

    // ---- labels for the settings screen ----
    class Option(val key: String, val title: String, val labels: Array<String>, val def: Int)

    val OPTIONS: Array<Option> = arrayOf(
        Option(K_FPS, "Smoothness (battery use)", arrayOf("Eco (lowest battery)", "Balanced", "Smooth (60 fps in motion)"), 1),
        Option(K_TIME_FORMAT, "Clock format", arrayOf("Follow phone", "12-hour", "24-hour"), 0),
        Option(K_SHOW_PERCENT, "Battery percent on lock screen", arrayOf("Hidden (rings only)", "Show small number"), 0),
        Option(K_WEATHER, "Weather", arrayOf("Off", "Occasional rain, fog and snow"), 1),
        Option(
            K_BIOME, "Landscape",
            arrayOf(
                "Journey (changes slowly)", "Woods", "Cornfields", "Desert", "Mountains", "Coast", "Snow", "Tea gardens"
            ), 0
        ),
        Option(K_PACE, "Journey length", arrayOf("Short (8 min per place)", "Normal (20 min)", "Long (45 min)"), 1),
        Option(
            K_TIME_OVERRIDE, "Time of day",
            arrayOf("Follow phone clock", "Always sunrise", "Always midday", "Always golden hour", "Always dusk", "Always night"), 0
        ),
        Option(K_ROAD_POS, "Scene height on home screen", arrayOf("Higher", "Default", "Lower"), 1)
    )
}
