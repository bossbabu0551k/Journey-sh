package com.endlessroad.wallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.PowerManager
import android.util.Log
import android.text.format.DateFormat
import java.util.Random
import java.util.TimeZone
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The whole wallpaper: owns the simulation (lock/unlock, charging, journey, weather) and draws it.
 * Called only from the main thread, except for the asset builders which run on background threads.
 */
class Scene(private val ctx: Context) {

    companion object {
        private fun newExec(name: String): ExecutorService =
            Executors.newSingleThreadExecutor { r ->
                val t = Thread(r, name)
                t.isDaemon = true
                t
            }

        private val BUILD_EXEC: ExecutorService = newExec("road-build")
        private val NEON_EXEC: ExecutorService = newExec("road-neon")

        private const val HOME_SPEED = 0.115f      // fraction of screen width per second
        private const val LOCK_SPEED = 1.25f
        private const val LOCK_WORLD_SCALE = 1.28f
        private const val YWL = 0.805f             // wheel line on the lock screen (fraction of H)
        private const val DIM = 0.28f
        private const val XF_TOTAL = 9.7f          // seconds for a landscape change to finish

        private val GREEN_GLOW = U.rgb(0x46FF78)
        private val GREEN_CORE = U.rgb(0xD7FFE1)
        private val BLUE_GLOW = U.rgb(0x2896FF)
        private val BLUE_CORE = U.rgb(0xCDE8FF)
        private val AMBER_GLOW = U.rgb(0xFFAA28)
        private val AMBER_CORE = U.rgb(0xFFE6BE)
        private val DARK_EDGE = U.rgb(0x0A1230)

        private val FPS_HOME = floatArrayOf(20f, 30f, 60f)
        private val FPS_LOCK = floatArrayOf(15f, 20f, 30f)
        private val FPS_PARK = floatArrayOf(8f, 10f, 15f)
        private val FPS_BURST = floatArrayOf(30f, 60f, 60f)
    }

    // ------------------------------------------------------------------ settings / geometry
    private var snap: Settings.Snap = Settings.load(ctx)
    private var W = 0f
    private var H = 0f
    private var geo: Geometry? = null
    private var preview = false

    // ------------------------------------------------------------------ paints
    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pMask = Paint(Paint.FILTER_BITMAP_FLAG)
    private val pLine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pStar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pSky = Paint()
    private val pFog = Paint()
    private val pText = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pAurG = Paint()
    private val pAurV = Paint()
    private val dst = RectF()
    private val rf = RectF()
    private val tmpPath = Path()

    // ------------------------------------------------------------------ sky and time
    private val sky = Sky()
    private val van = VanRenderer()
    private val vanState = VanState()
    private var hour = 12f
    private var nowMs = 0L
    private var tzOff = 0
    private var tzTimer = 0f
    private var use24 = false
    private var wantText = ""
    private var minuteKey = -1L
    private var skyShader: LinearGradient? = null
    private var skyKey = 0
    private var skyBuiltMs = 0L

    // ------------------------------------------------------------------ timeline state
    private var lastNanos = 0L
    private var time = 0f
    private var distance = 0.0
    private var speed = 1f
    private var prevSpeed = 1f
    private var q = 0f                  // 0 = home, 1 = lock screen
    private var qTarget = 0f
    private var camera = 0f
    private var blur = 0f
    private var neonQ = 0f
    private var wakeT = 99f
    private var wakeFade = 1f
    private var awaitNeon = false
    private var nudge = 0f
    private var nudgeGo = false
    private var park = 0f
    private var rush = 0f
    private var zoomTarget = 0f
    private var zoomS = 0f
    private var zoomSeen = false
    private var pitch = 0f
    private var wheelDeg = 0f
    private var visible = false
    private var powerSave = false
    private var powerTimer = 0f
    private var demoState = 0
    private var hintT = 0f
    private val pm: PowerManager? = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager

    // ------------------------------------------------------------------ battery visuals
    private var level = 80
    private var charging = false
    private var blueMix = 0f
    private var amberMix = 0f
    private val ringReal = FloatArray(4)
    private val ringDisp = FloatArray(4)
    private var flourishT = -1f
    private var sweepT = -1f
    private var sweepPending = false

    // ------------------------------------------------------------------ journey / assets
    private var cur: BiomeAssets? = null
    private var nxt: BiomeAssets? = null
    private var curId = Settings.loadJourneyBiome(ctx)
    private var biomeTime = Settings.loadJourneyTime(ctx)
    private var xfT = -1f
    private var revealT = 0f
    private var building = false
    private var retryT = 0f

    @Volatile
    private var buildToken = 0

    @Volatile
    private var readyAssets: BiomeAssets? = null

    @Volatile
    private var readyFlag = false

    // ------------------------------------------------------------------ neon clock
    private var neonCur: NeonMasks? = null
    private var neonStaged: NeonMasks? = null
    private var neonUnit = 1f
    private var neonJobText = ""
    private var neonCooldown = 0f

    @Volatile
    private var neonIncoming: NeonMasks? = null

    @Volatile
    private var neonJobDone = true

    @Volatile
    private var neonFailed = false

    // ------------------------------------------------------------------ weather and particles
    private val rnd = Random(12345L)
    private var wxType = 0              // 0 none, 1 rain, 2 fog, 3 snow
    private var wxTarget = 0f
    private var wxI = 0f
    private var wxTimer = 120f + 120f * rnd.nextFloat()
    private var fogColor = 0
    private var fogShader: LinearGradient? = null

    private val starN = 90
    private val starFx = FloatArray(starN)
    private val starFy = FloatArray(starN)
    private val starPts = FloatArray(starN * 2)
    private val starPh = FloatArray(starN)

    private val ffN = 16
    private val ffX = FloatArray(ffN)
    private val ffY = FloatArray(ffN)
    private val ffP = FloatArray(ffN)
    private val ffR = FloatArray(ffN)

    private val dropN = 80
    private val dropX = FloatArray(dropN)
    private val dropY = FloatArray(dropN)
    private val dropV = FloatArray(dropN)
    private val dropPts = FloatArray(dropN * 4)
    private val flakeN = 70
    private val flakePts = FloatArray(flakeN * 2)

    private val cloudN = 5
    private val cloudX = FloatArray(cloudN)
    private val cloudY = FloatArray(cloudN)
    private val cloudS = FloatArray(cloudN)
    private val cloudV = FloatArray(cloudN)
    private val cloudSharp: Bitmap
    private val cloudSoft: Bitmap

    private var shootT = -1f
    private var shootTimer = 20f
    private var shootX = 0f
    private var shootY = 0f
    private var planeT = -1f
    private var planeTimer = 150f
    private var planeY = 0f

    private val tileXs = FloatArray(4)
    private var tileN = 0

    init {
        pFill.style = Paint.Style.FILL
        pLine.style = Paint.Style.STROKE
        pLine.strokeCap = Paint.Cap.ROUND
        pStar.style = Paint.Style.STROKE
        pStar.strokeCap = Paint.Cap.ROUND
        pStar.strokeWidth = 2.4f
        pSky.isDither = true
        pText.textAlign = Paint.Align.CENTER
        pText.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        pText.letterSpacing = 0.14f

        pAurG.shader = LinearGradient(
            0f, 0f, 0f, 1f,
            intArrayOf(U.withAlpha(0x3CFFA0, 0f), U.withAlpha(0x3CFFA0, 0.85f), U.withAlpha(0x2AC8C0, 0.5f), U.withAlpha(0x2AC8C0, 0f)),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        pAurV.shader = LinearGradient(
            0f, 0f, 0f, 1f,
            intArrayOf(U.withAlpha(0xA070FF, 0f), U.withAlpha(0xA070FF, 0.7f), U.withAlpha(0x50A0FF, 0.4f), U.withAlpha(0x50A0FF, 0f)),
            floatArrayOf(0f, 0.3f, 0.7f, 1f), Shader.TileMode.CLAMP
        )

        for (i in 0 until starN) {
            starFx[i] = rnd.nextFloat()
            starFy[i] = rnd.nextFloat() * 0.58f
            starPh[i] = rnd.nextFloat() * 6.28f
        }
        for (i in 0 until ffN) {
            ffX[i] = rnd.nextFloat()
            ffY[i] = rnd.nextFloat()
            ffP[i] = rnd.nextFloat() * 6.28f
            ffR[i] = rnd.nextFloat()
        }
        for (i in 0 until dropN) {
            dropX[i] = rnd.nextFloat()
            dropY[i] = rnd.nextFloat()
            dropV[i] = 0.8f + 0.5f * rnd.nextFloat()
        }
        for (i in 0 until cloudN) {
            cloudX[i] = rnd.nextFloat()
            cloudY[i] = 0.07f + 0.30f * rnd.nextFloat()
            cloudS[i] = 0.7f + 0.9f * rnd.nextFloat()
            cloudV[i] = 3f + 6f * rnd.nextFloat()
        }
        cloudSharp = makeCloud(1f, 360, 120)
        cloudSoft = makeCloud(1f / 6f, 60, 20)
        use24 = DateFormat.is24HourFormat(ctx)
    }

    private fun makeCloud(scale: Float, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
        val c = Canvas(b)
        c.scale(scale, scale)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawOval(10f, 64f, 120f, 112f, p)
        c.drawOval(80f, 40f, 200f, 112f, p)
        c.drawOval(160f, 52f, 280f, 112f, p)
        c.drawOval(230f, 66f, 350f, 112f, p)
        c.drawOval(110f, 18f, 230f, 92f, p)
        c.drawRect(40f, 92f, 330f, 112f, p)
        return b
    }

    // ================================================================== public API

    fun setPreview(p: Boolean) {
        preview = p
    }

    fun applySettings(s: Settings.Snap) {
        val old = snap
        snap = s
        if (geo != null && old.roadPos != s.roadPos) {
            rebuildGeometry()
        }
        if (old.timeFormat != s.timeFormat) {
            minuteKey = -1L
            neonCur = null
            neonStaged = null
        }
    }

    fun resize(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        if (geo != null && w.toFloat() == W && h.toFloat() == H) return
        W = w.toFloat()
        H = h.toFloat()
        rebuildGeometry()
    }

    private fun rebuildGeometry() {
        val rfr = when (snap.roadPos) {
            0 -> 0.835f
            2 -> 0.885f
            else -> 0.862f
        }
        geo = Geometry(W, H, rfr)
        // particles that depend on pixel positions
        for (i in 0 until starN) {
            starPts[i * 2] = starFx[i] * W
            starPts[i * 2 + 1] = starFy[i] * H
        }
        skyShader = null
        neonUnit = min(0.84f * W / Neon.referenceWidthUnits(), 0.20f * H / Neon.referenceHeightUnits())
        neonCur = null
        neonStaged = null
        cur = null
        nxt = null
        xfT = -1f
        revealT = 0f
        building = false
        buildToken++
        val fixed = snap.biome - 1
        requestAssets(if (fixed >= 0) fixed else curId, false)
    }

    /** The engine became visible. */
    fun onShow(locked: Boolean, returningFromApp: Boolean) {
        visible = true
        lastNanos = 0L
        if (locked) {
            q = 1f
            qTarget = 1f
            camera = 1f
            blur = 1f
            neonQ = 1f
            wakeT = 0f
            wakeFade = 0f
            awaitNeon = true
            nudge = 0f
            nudgeGo = !charging
            park = if (charging) 1f else 0f
            blueMix = if (charging) 1f else 0f
            amberMix = if (!charging && level < 15) 1f else 0f
            computeRingTargets()
            for (k in 0 until 4) ringDisp[k] = ringReal[k]
            ringDisp[0] = 1f
            flourishT = -1f
            sweepT = -1f
            sweepPending = level >= 100
            rush = 0f
        } else {
            if (qTarget > 0.5f || q > 0.5f) {
                qTarget = 0f            // we were locked while hidden: play the unlock
            } else {
                q = 0f
                qTarget = 0f
                if (returningFromApp && !zoomSeen && !preview) rush = 1f
            }
        }
        speed = speedTarget()
        prevSpeed = speed
    }

    fun onHide() {
        visible = false
        Settings.saveJourney(ctx, curId, biomeTime)
    }

    /** Keyguard state changed while visible. */
    fun setLocked(locked: Boolean) {
        qTarget = if (locked) 1f else 0f
    }

    fun setBattery(pct: Int, chg: Boolean) {
        val was = charging
        level = pct.coerceIn(0, 100)
        charging = chg
        computeRingTargets()
        if (chg && !was && visible && q > 0.5f) {
            flourishT = 0f
            sweepPending = level >= 100
        }
        if (!chg && was && visible && q > 0.5f) {
            sweepPending = false
        }
    }

    fun onZoom(z: Float) {
        if (z > 0.001f) zoomSeen = true
        zoomTarget = U.clamp01(z)
    }

    /** Preview screen: each tap advances home -> lock -> plugged in -> full -> home. */
    fun demoNext() {
        demoState = (demoState + 1) % 4
        when (demoState) {
            0 -> {
                setBattery(72, false)
                setLocked(false)
            }
            1 -> {
                setBattery(72, false)
                setLocked(true)
                wakeT = 0f
                wakeFade = 0f
                awaitNeon = true
                nudge = 0f
                nudgeGo = true
            }
            2 -> setBattery(72, true)
            else -> setBattery(100, true)
        }
    }

    fun isPreview(): Boolean = preview

    /** Primary / secondary / tertiary colours for the system's wallpaper theming. */
    fun themeColors(): IntArray = intArrayOf(sky.top, sky.hor, cur?.def?.fgColor ?: sky.mid)

    fun themeKey(): Int = (hour * 2f).toInt() * 16 + curId

    fun desiredFps(): Float {
        val tier = if (powerSave) 0 else snap.fps.coerceIn(0, 2)
        val burst = q != qTarget || rush > 0f || zoomS > 0.01f || abs(zoomTarget - zoomS) > 0.005f ||
            wakeT < 0.8f || flourishT >= 0f || sweepT >= 0f || (park > 0.001f && park < 0.999f)
        if (burst) return FPS_BURST[tier]
        if (q > 0.5f) {
            return if (park > 0.99f) FPS_PARK[tier] else FPS_LOCK[tier]
        }
        return FPS_HOME[tier]
    }

    fun frame(frameNanos: Long, c: Canvas) {
        step(frameNanos)
        draw(c)
    }

    fun release() {
        buildToken++
        cur = null
        nxt = null
        neonCur = null
        neonStaged = null
    }

    // ================================================================== simulation

    private fun approach(v: Float, target: Float, d: Float): Float =
        if (v < target) min(target, v + d) else max(target, v - d)

    private fun computeRingTargets() {
        ringReal[0] = 1f
        ringReal[1] = if (level >= 50) 1f else if (level >= 20) DIM else 0f
        ringReal[2] = if (level >= 80) 1f else if (level >= 50) DIM else 0f
        ringReal[3] = if (level >= 100) 1f else if (level >= 80) DIM else 0f
    }

    private fun speedTarget(): Float {
        val parkEase = U.smoother(park)
        val base = U.lerp(1f, LOCK_SPEED, camera)
        return base * (1f - parkEase) * (1f + 1.4f * zoomS) * (1f + 2.2f * U.smooth(rush))
    }

    private fun updateClock(dt: Float) {
        nowMs = System.currentTimeMillis()
        tzTimer -= dt
        if (tzTimer <= 0f) {
            tzTimer = 2f
            tzOff = TimeZone.getDefault().getOffset(nowMs)
            use24 = when (snap.timeFormat) {
                1 -> false
                2 -> true
                else -> DateFormat.is24HourFormat(ctx)
            }
        }
        val sec = (((nowMs + tzOff) / 1000L) % 86400L + 86400L) % 86400L
        hour = when (snap.timeOverride) {
            1 -> 6.6f
            2 -> 12.5f
            3 -> 17.6f
            4 -> 19.2f
            5 -> 23.5f
            else -> sec / 3600f
        }
        val mk = (nowMs + tzOff) / 60000L
        if (mk != minuteKey) {
            minuteKey = mk
            wantText = clockText(nowMs)
        }
        sky.update(hour, nowMs)
        if (wxI > 0.01f && wxType != 0) {
            val k = wxI * 0.30f
            val gray = U.rgb(0x7B8590)
            sky.top = U.mix(sky.top, gray, k)
            sky.mid = U.mix(sky.mid, gray, k)
            sky.hor = U.mix(sky.hor, gray, k * 0.8f)
        }
    }

    private fun clockText(ms: Long): String {
        val sec = (((ms + tzOff) / 1000L) % 86400L + 86400L) % 86400L
        var h = (sec / 3600L).toInt()
        val m = ((sec / 60L) % 60L).toInt()
        if (!use24) {
            h %= 12
            if (h == 0) h = 12
        }
        val hs = if (use24 && h < 10) "0$h" else "$h"
        val ms2 = if (m < 10) "0$m" else "$m"
        return "$hs:$ms2"
    }

    private fun step(frameNanos: Long) {
        val dt = if (lastNanos == 0L) 0.001f else ((frameNanos - lastNanos) / 1.0e9f).coerceIn(0f, 0.1f)
        lastNanos = frameNanos
        time += dt

        updateClock(dt)

        powerTimer -= dt
        if (powerTimer <= 0f) {
            powerTimer = 5f
            powerSave = try {
                pm?.isPowerSaveMode ?: false
            } catch (e: Exception) {
                false
            }
        }

        // --- lock / home transition
        val dq = dt / 1.1f
        q = approach(q, qTarget, dq)
        camera = U.smoother(q)
        blur = U.smooth(U.ramp(0.364f, 1f, q))
        neonQ = U.smooth(U.ramp(0.773f, 1f, q))

        // --- wake sequence
        val neonOk = neonCur?.text == wantText
        if (awaitNeon) {
            if (neonOk || q < 0.5f) awaitNeon = false else wakeT = 0f
        }
        wakeT += dt
        wakeFade = U.smooth(wakeT / 0.25f)
        if (nudgeGo && !awaitNeon) {
            nudge = min(1f, nudge + dt / 0.5f)
        }

        // --- parking while charging on the lock screen
        val parkTarget = if (charging && q > 0.5f) 1f else 0f
        park = approach(park, parkTarget, if (parkTarget > park) dt / 1.2f else dt / 1.5f)

        rush = max(0f, rush - dt / 0.8f)
        zoomS += (zoomTarget - zoomS) * (1f - exp(-dt / 0.12f))

        // --- speed, distance, wheels, nose dip
        val st = speedTarget()
        speed += (st - speed) * (1f - exp(-dt / 0.25f))
        if (st == 0f && speed < 0.002f) speed = 0f
        val decel = (prevSpeed - speed) / max(dt, 0.001f)
        prevSpeed = speed
        val pitchTarget = (decel * 1.6f).coerceIn(-1.2f, 2.2f)
        pitch += (pitchTarget - pitch) * (1f - exp(-dt / 0.18f))

        val ground = HOME_SPEED * W
        distance += (ground * speed * dt).toDouble()
        val vs = vanScale()
        val sw = worldScale()
        if (vs > 0f) {
            wheelDeg += (ground * speed * sw) / (VanRenderer.WHEEL_R * vs) * 57.29578f * dt
            if (wheelDeg > 360f) wheelDeg -= 360f
        }

        if (preview && demoState == 0) hintT += dt

        // --- battery visuals
        blueMix = approach(blueMix, if (charging) 1f else 0f, dt * 2f)
        amberMix = approach(amberMix, if (!charging && level < 15) 1f else 0f, dt * 2f)
        val ease = 1f - exp(-dt / 0.25f)
        for (k in 1 until 4) ringDisp[k] += (ringReal[k] - ringDisp[k]) * ease
        ringDisp[0] = 1f
        if (flourishT >= 0f) {
            flourishT += dt
            if (flourishT > 1.5f) flourishT = -1f
        }
        if (sweepPending && level >= 100 && neonQ > 0.99f && wakeFade > 0.99f && flourishT < 0f && !awaitNeon) {
            sweepT = 0f
            sweepPending = false
        }
        if (sweepT >= 0f) {
            sweepT += dt
            if (sweepT > 1.0f) sweepT = -1f
        }

        safeStep { if (qTarget > 0.5f || q > 0.05f) stepNeon(dt) }
        safeStep { pollAssets(dt) }
        safeStep { updateJourney(dt) }
        safeStep { updateWeather(dt) }
        safeStep { updateSkyEvents(dt) }
    }

    private var partErrors = 0

    private fun logPart(e: Exception) {
        if (partErrors < 8) {
            partErrors++
            Log.w("EndlessRoad", "a part of the scene failed", e)
        }
    }

    /** Keeps a bug in one simulation part from stopping the whole wallpaper. */
    private inline fun safeStep(block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            logPart(e)
        }
    }

    /** Same for drawing: a failing part is skipped and the canvas state is restored. */
    private inline fun safe(c: Canvas, block: () -> Unit) {
        val saved = c.save()
        try {
            block()
        } catch (e: Exception) {
            logPart(e)
        } finally {
            c.restoreToCount(saved)
        }
    }

    private fun stepNeon(dt: Float) {
        val inc = neonIncoming
        if (inc != null) {
            neonIncoming = null
            if (inc.unit == neonUnit) {
                if (inc.text == wantText) neonCur = inc else neonStaged = inc
            }
        }
        val st = neonStaged
        if (st != null && st.text == wantText) {
            neonCur = st
            neonStaged = null
        }
        if (neonFailed) {
            neonFailed = false
            neonCooldown = 5f
        }
        if (neonCooldown > 0f) {
            neonCooldown -= dt
            return
        }
        if (!neonJobDone) return
        val cu = neonCur
        if (cu == null || cu.text != wantText) {
            if (neonStaged?.text != wantText) startNeonJob(wantText)
        } else if (neonStaged == null) {
            val secInMin = ((nowMs + tzOff) / 1000L) % 60L
            if (secInMin >= 45L) startNeonJob(clockText(nowMs + 60000L))
        }
    }

    private fun startNeonJob(text: String) {
        neonJobDone = false
        neonJobText = text
        val u = neonUnit
        NEON_EXEC.execute {
            var r: NeonMasks? = null
            try {
                r = Neon.render(text, u)
            } catch (t: Throwable) {
                r = null
            }
            if (r == null) neonFailed = true
            neonIncoming = r
            neonJobDone = true
        }
    }

    // ---------------------------------------------------------------- journey

    private fun requestAssets(id: Int, forNext: Boolean) {
        val g = geo ?: return
        building = true
        buildToken++
        val token = buildToken
        BUILD_EXEC.execute {
            var res: BiomeAssets? = null
            try {
                res = Biomes.build(id, g)
            } catch (t: Throwable) {
                res = null
            }
            if (token == buildToken) {
                readyAssets = res
                readyFlag = true
            }
        }
    }

    private fun pollAssets(dt: Float) {
        if (readyFlag) {
            readyFlag = false
            building = false
            val a = readyAssets
            readyAssets = null
            val g = geo
            if (a == null) {
                retryT = 8f
            } else if (g != null && a.geoKey == g.key) {
                if (cur == null) {
                    cur = a
                    curId = a.def.id
                    revealT = 0f
                } else {
                    nxt = a
                    xfT = -1f
                }
            }
        }
        if (retryT > 0f) {
            retryT -= dt
            if (retryT <= 0f && !building && cur == null) {
                val fixed = snap.biome - 1
                requestAssets(if (fixed >= 0) fixed else curId, false)
            }
        }
    }

    private fun durationSec(): Float = when (snap.pace) {
        0 -> 480f
        2 -> 2700f
        else -> 1200f
    }

    private fun updateJourney(dt: Float) {
        if (cur == null) return
        revealT += dt
        val fixed = snap.biome - 1
        val nx = nxt
        if (fixed >= 0) {
            if (curId != fixed && nx == null && !building) requestAssets(fixed, true)
            if (nx != null && xfT < 0f) {
                if (nx.def.id == fixed) xfT = 0f else nxt = null
            }
        } else {
            biomeTime += dt
            val dur = durationSec()
            if (nx == null && !building && biomeTime > dur * 0.75f) {
                requestAssets((curId + 1) % Biomes.COUNT, true)
            }
            if (nx != null && xfT < 0f && biomeTime >= dur) xfT = 0f
        }
        if (xfT >= 0f) {
            xfT += dt
            val n2 = nxt
            if (xfT > XF_TOTAL && n2 != null) {
                cur = n2
                curId = n2.def.id
                nxt = null
                xfT = -1f
                biomeTime = 0f
                Settings.saveJourney(ctx, curId, 0f)
            }
        }
    }

    // ---------------------------------------------------------------- weather and sky events

    private fun updateWeather(dt: Float) {
        if (snap.weather == 0 || powerSave) {
            wxTarget = 0f
        } else {
            wxTimer -= dt
            if (wxTimer <= 0f) {
                if (wxTarget > 0f) {
                    wxTarget = 0f
                    wxTimer = 360f + 480f * rnd.nextFloat()
                } else if (rnd.nextFloat() < 0.5f) {
                    wxTimer = 300f + 300f * rnd.nextFloat()
                } else {
                    val snowy = cur?.def?.snowy == true
                    wxType = if (snowy) 3 else if (rnd.nextFloat() < 0.55f) 1 else 2
                    wxTarget = 1f
                    wxTimer = 150f + 210f * rnd.nextFloat()
                }
            }
        }
        wxI = approach(wxI, wxTarget, dt / 20f)
        if (wxI <= 0f && wxTarget == 0f) wxType = 0
    }

    private fun updateSkyEvents(dt: Float) {
        // shooting star
        if (shootT >= 0f) {
            shootT += dt
            if (shootT > 0.9f) shootT = -1f
        } else if (sky.stars > 0.6f) {
            shootTimer -= dt
            if (shootTimer <= 0f) {
                shootT = 0f
                shootX = W * (0.35f + 0.55f * rnd.nextFloat())
                shootY = H * (0.04f + 0.20f * rnd.nextFloat())
                shootTimer = 25f + 45f * rnd.nextFloat()
            }
        }
        // distant plane with a contrail
        if (planeT >= 0f) {
            planeT += dt
            if (planeT > 70f) planeT = -1f
        } else if (sky.day > 0.7f && wxType == 0) {
            planeTimer -= dt
            if (planeTimer <= 0f) {
                planeT = 0f
                planeY = H * (0.07f + 0.14f * rnd.nextFloat())
                planeTimer = 240f + 240f * rnd.nextFloat()
            }
        }
    }

    // ================================================================== layout helpers

    private fun vanScale(): Float {
        val homeVs = 0.30f * W / VanRenderer.LENGTH
        val lockVs = 0.80f * W / VanRenderer.LENGTH
        val n = U.smooth(nudge)
        return U.lerp(homeVs, lockVs * (1f + 0.05f * n), camera)
    }

    private fun worldScale(): Float = U.lerp(1f, LOCK_WORLD_SCALE, camera)

    // ================================================================== drawing

    private fun draw(c: Canvas) {
        val g = geo
        if (g == null || W <= 0f) {
            c.drawColor(sky.mid)
            return
        }
        safe(c) { drawSky(c) }
        safe(c) { drawCelestial(c) }
        safe(c) { drawClouds(c) }
        safe(c) { if (cur?.def?.aurora == true) drawAurora(c) }

        val n = U.smooth(nudge)
        val vs = vanScale()
        val sw = worldScale()
        val vanX = U.lerp(0.40f * W, 0.5f * W, camera)
        val vanY = U.lerp(g.yW, YWL * H + 0.004f * H * n, camera)
        val zs = 1f - 0.06f * zoomS

        c.save()
        if (zs != 1f) c.scale(zs, zs, W / 2f, vanY)

        // ---- world (camera moves with the lock transition)
        c.save()
        c.translate(W / 2f, vanY)
        c.scale(sw, sw)
        c.translate(-W / 2f, -g.yW)
        safe(c) { drawLayers(c, g) }
        safe(c) { drawRoad(c, g) }
        safe(c) { drawForeground(c, g) }
        c.restore()

        safe(c) { drawFireflies(c, g) }
        safe(c) { drawNeon(c) }

        // ---- the van
        val vs2 = vanState
        vs2.x = vanX
        vs2.y = vanY
        vs2.scale = vs
        vs2.wheelDeg = wheelDeg
        vs2.pitchDeg = pitch
        vs2.bob = sin(time * 5.3f) * 0.35f * min(1f, speed)
        vs2.lamp = sky.lamp
        vs2.detail = U.smooth(U.ramp(0.5f, 1f, camera))
        vs2.time = time
        safe(c) { van.draw(c, vs2) }

        c.restore()

        safe(c) { drawWeather(c) }
        safe(c) { drawHint(c) }
    }

    private fun drawSky(c: Canvas) {
        val key = sky.top * 31 + sky.mid * 17 + sky.hor
        if (skyShader == null || (key != skyKey && nowMs - skyBuiltMs > 400L)) {
            skyKey = key
            skyBuiltMs = nowMs
            skyShader = LinearGradient(
                0f, 0f, 0f, H,
                intArrayOf(sky.top, sky.mid, sky.hor, U.mix(sky.hor, sky.mid, 0.3f)),
                floatArrayOf(0f, 0.38f, 0.66f, 1f), Shader.TileMode.CLAMP
            )
            pSky.shader = skyShader
        }
        c.drawRect(0f, 0f, W, H, pSky)
    }

    private fun drawCelestial(c: Canvas) {
        val sc = W / 720f
        val k = 1f + 0.5f * camera
        // stars
        if (sky.stars > 0.01f) {
            pStar.color = U.withAlpha(0xFFFFFF, sky.stars * 0.75f)
            c.drawPoints(starPts, 0, starN * 2, pStar)
            pFill.color = U.withAlpha(0xFFFFFF, sky.stars)
            for (i in 0 until 12) {
                val a = 0.35f + 0.65f * (0.5f + 0.5f * sin(time * 1.3f + starPh[i]))
                pFill.color = U.withAlpha(0xFFFFFF, sky.stars * a)
                c.drawCircle(starPts[i * 2], starPts[i * 2 + 1], 1.9f * sc + 0.5f, pFill)
            }
        }
        // shooting star
        if (shootT >= 0f) {
            val p = shootT / 0.9f
            val fade = sin(PI.toFloat() * p)
            for (j in 0 until 6) {
                val t0 = p - j * 0.03f
                val t1 = p - (j + 1) * 0.03f
                if (t1 < 0f) break
                pLine.color = U.withAlpha(0xFFFFFF, fade * (1f - j / 6f) * 0.9f)
                pLine.strokeWidth = 2.2f * sc + 0.4f
                c.drawLine(
                    shootX - t0 * W * 0.34f, shootY + t0 * H * 0.14f,
                    shootX - t1 * W * 0.34f, shootY + t1 * H * 0.14f, pLine
                )
            }
        }
        // sun
        if (sky.sunAlpha > 0.01f) {
            val u = U.clamp01(sky.sunU)
            val sx = W * (0.12f + 0.76f * u)
            val sy = 0.64f * H - sky.sunArc * H * 0.38f
            val a = sky.sunAlpha
            pFill.color = U.withAlpha(sky.sunColor, 0.12f * a)
            c.drawCircle(sx, sy, 62f * sc * k, pFill)
            pFill.color = U.withAlpha(sky.sunColor, 0.20f * a)
            c.drawCircle(sx, sy, 42f * sc * k, pFill)
            pFill.color = U.withAlpha(sky.sunColor, 0.35f * a)
            c.drawCircle(sx, sy, 29f * sc * k, pFill)
            pFill.color = U.withAlpha(sky.sunColor, a)
            c.drawCircle(sx, sy, 20f * sc, pFill)
        }
        // moon
        if (sky.moonAlpha > 0.01f) {
            val u = U.clamp01(sky.moonU)
            val mx = W * (0.12f + 0.76f * u)
            val my = 0.64f * H - sin(PI.toFloat() * u) * H * 0.36f
            drawMoon(c, mx, my, 22f * sc, sky.moonPhase, sky.moonAlpha, k)
        }
        // plane and contrail
        if (planeT >= 0f) {
            val p = planeT / 70f
            val px = -0.1f * W + p * 1.2f * W
            val py = planeY + p * H * 0.03f
            val fade = sin(PI.toFloat() * p)
            for (j in 0 until 6) {
                val x0 = px - j * 34f * sc
                val x1 = px - (j + 1) * 34f * sc
                pLine.color = U.withAlpha(0xFFFFFF, 0.35f * fade * (1f - j / 6f))
                pLine.strokeWidth = 2.4f * sc
                c.drawLine(x0, py - j * 0.5f, x1, py - (j + 1) * 0.5f, pLine)
            }
            pFill.color = U.withAlpha(0xFFFFFF, 0.8f * fade)
            c.drawCircle(px, py, 1.8f * sc + 0.4f, pFill)
        }
    }

    private fun drawMoon(c: Canvas, x: Float, y: Float, r: Float, phase: Float, alpha: Float, k: Float) {
        pFill.color = U.withAlpha(0xC8D7FF, 0.10f * alpha)
        c.drawCircle(x, y, r * 2.6f * k, pFill)
        pFill.color = U.withAlpha(0xC8D7FF, 0.18f * alpha)
        c.drawCircle(x, y, r * 1.7f * k, pFill)
        // dark side
        pFill.color = U.withAlpha(0x20284A, 0.55f * alpha)
        c.drawCircle(x, y, r, pFill)
        // lit part
        val waning = phase > 0.5f
        val pp = if (waning) 1f - phase else phase
        val cosv = cos(2f * PI.toFloat() * pp)
        val a = max(0.5f, abs(cosv) * r)
        c.save()
        c.translate(x, y)
        if (waning) c.scale(-1f, 1f)
        tmpPath.reset()
        tmpPath.moveTo(0f, -r)
        rf.set(-r, -r, r, r)
        tmpPath.arcTo(rf, -90f, 180f, false)
        rf.set(-a, -r, a, r)
        if (cosv > 0f) {
            tmpPath.arcTo(rf, 90f, -180f, false)
        } else {
            tmpPath.arcTo(rf, 90f, 180f, false)
        }
        tmpPath.close()
        pFill.color = U.withAlpha(0xF4F1E0, alpha)
        c.drawPath(tmpPath, pFill)
        c.restore()
    }

    private fun drawClouds(c: Canvas) {
        val sc = W / 720f
        val col0 = U.mul(U.rgb(0xFFFFFF), sky.ar, sky.ag, sky.ab)
        val col = U.mix(col0, sky.mid, 0.30f + 0.25f * wxI)
        val bmp = if (blur > 0.5f) cloudSoft else cloudSharp
        pMask.color = U.withAlpha(col, 0.82f)
        for (i in 0 until cloudN) {
            val k = sc * cloudS[i]
            val cw = 360f * k
            val span = W + cw
            val x = ((cloudX[i] * W + time * cloudV[i] + (distance * 0.004).toFloat()) % span + span) % span - cw
            val y = cloudY[i] * H
            dst.set(x, y, x + cw, y + 120f * k)
            c.drawBitmap(bmp, null, dst, pMask)
        }
    }

    private fun drawAurora(c: Canvas) {
        val a = sky.stars
        if (a < 0.02f) return
        val strips = 26
        val sw = W / strips
        for (layer in 0 until 2) {
            val paint = if (layer == 0) pAurG else pAurV
            for (i in 0 until strips) {
                val ph = i * 0.37f + layer * 1.9f + time * (0.22f + 0.10f * layer)
                val hgt = H * (0.16f + 0.06f * sin(ph) + 0.04f * layer)
                val top = H * (0.20f + 0.08f * sin(ph * 0.7f + 1f) + 0.05f * layer)
                val al = (255f * a * 0.42f * (0.6f + 0.4f * sin(ph * 1.3f))).toInt()
                paint.alpha = al.coerceIn(0, 255)
                c.save()
                c.translate(i * sw, top)
                c.scale(1f, hgt)
                c.drawRect(0f, 0f, sw + 1f, 1f, paint)
                c.restore()
            }
        }
    }

    // ---- scenery layers -------------------------------------------------

    private fun computeTiles(scroll: Double, tile: Float) {
        tileN = 0
        var x = -U.fmod(scroll, tile.toDouble()).toFloat() - tile
        while (x < W * 1.12f && tileN < 4) {
            if (x + tile > -W * 0.12f) {
                tileXs[tileN] = x
                tileN++
            }
            x += tile
        }
    }

    private fun drawTiles(c: Canvas, bmp: Bitmap, tile: Float, top: Float, hgt: Float, color: Int) {
        pMask.color = color
        for (i in 0 until tileN) {
            val x = tileXs[i]
            dst.set(x, top, x + tile + 1f, top + hgt)
            c.drawBitmap(bmp, null, dst, pMask)
        }
    }

    private fun drawMask(c: Canvas, la: LayerAsset, g: Geometry, scroll: Double, color: Int, alpha: Float, b: Float) {
        val tile = g.tile.toFloat()
        val hgt = la.sharp.height.toFloat()
        computeTiles(scroll, tile)
        if (b <= 0.002f) {
            drawTiles(c, la.sharp, tile, la.top, hgt, U.withAlpha(color, alpha))
        } else if (b >= 0.998f) {
            drawTiles(c, la.soft, tile, la.top, hgt, U.withAlpha(color, alpha))
        } else if (b < 0.5f) {
            drawTiles(c, la.sharp, tile, la.top, hgt, U.withAlpha(color, alpha))
            drawTiles(c, la.soft, tile, la.top, hgt, U.withAlpha(color, alpha * b * 2f))
        } else {
            drawTiles(c, la.soft, tile, la.top, hgt, U.withAlpha(color, alpha))
            drawTiles(c, la.sharp, tile, la.top, hgt, U.withAlpha(color, alpha * (1f - b) * 2f))
        }
    }

    private fun layerColor(def: LayerDef, mist: Float): Int {
        val lit = U.mul(def.color, sky.ar, sky.ag, sky.ab)
        return U.mix(lit, sky.hor, def.haze + mist)
    }

    private fun blurAmount(): Float = max(blur, 0.6f * zoomS)

    private fun drawLayer(c: Canvas, g: Geometry, la: LayerAsset, alpha: Float, mist: Float) {
        if (alpha <= 0.003f) return
        val color = layerColor(la.def, mist)
        val scroll = distance * la.def.par
        drawMask(c, la, g, scroll, color, alpha, blurAmount())
        if (la.windmills.isNotEmpty()) drawWindmills(c, g, la, scroll, color, alpha)
        if (la.lights.isNotEmpty() && sky.lamp > 0.02f) drawLamps(c, g, la, scroll, alpha)
    }

    private fun drawWindmills(c: Canvas, g: Geometry, la: LayerAsset, scroll: Double, color: Int, alpha: Float) {
        computeTiles(scroll, g.tile.toFloat())
        pLine.color = U.withAlpha(color, alpha)
        pLine.strokeWidth = 2.6f * W / 720f
        val ang = time * 0.55f
        for (t in 0 until tileN) {
            var i = 0
            while (i + 2 < la.windmills.size) {
                val hx = tileXs[t] + la.windmills[i]
                val hy = la.top + la.windmills[i + 1]
                val len = la.windmills[i + 2]
                for (b in 0 until 4) {
                    val a = ang + b * (PI.toFloat() / 2f)
                    c.drawLine(hx, hy, hx + cos(a) * len, hy + sin(a) * len, pLine)
                }
                i += 3
            }
        }
    }

    private fun drawLamps(c: Canvas, g: Geometry, la: LayerAsset, scroll: Double, alpha: Float) {
        computeTiles(scroll, g.tile.toFloat())
        val a = sky.lamp * alpha * (1f - 0.5f * blurAmount())
        val sc = W / 720f
        for (t in 0 until tileN) {
            var i = 0
            while (i + 1 < la.lights.size) {
                val lx = tileXs[t] + la.lights[i]
                val ly = la.top + la.lights[i + 1]
                pFill.color = U.withAlpha(0xFFD28A, a * 0.07f)
                c.drawCircle(lx, ly, 46f * sc, pFill)
                pFill.color = U.withAlpha(0xFFD28A, a * 0.13f)
                c.drawCircle(lx, ly, 24f * sc, pFill)
                pFill.color = U.withAlpha(0xFFE8B0, a * 0.60f)
                c.drawCircle(lx, ly, 8f * sc, pFill)
                i += 2
            }
        }
    }

    private fun revealAlpha(i: Int): Float = U.smooth((revealT - 0.06f * i) / 0.5f)

    private fun drawLayers(c: Canvas, g: Geometry) {
        val cu = cur ?: return
        val nx = nxt
        val xfMist = if (xfT >= 0f) sin(PI.toFloat() * U.clamp01(xfT / XF_TOTAL)) * 0.22f else 0f
        val mist = xfMist + (if (wxType == 2) 0.35f * wxI else 0f)
        for (i in 0 until 8) {
            val cl = cu.layers[i]
            val nl: LayerAsset? = if (nx != null && xfT >= 0f) nx.layers[i] else null
            val p = if (nl != null) U.clamp01((xfT - i * 0.9f) / 3.2f) else 0f
            val rv = revealAlpha(i)
            if (nl == null || p <= 0f) {
                drawLayer(c, g, cl, rv, mist)
            } else if (p >= 1f) {
                drawLayer(c, g, nl, 1f, mist)
            } else if (p < 0.6f) {
                drawLayer(c, g, cl, 1f, mist)
                drawLayer(c, g, nl, p / 0.6f, mist)
            } else {
                drawLayer(c, g, nl, 1f, mist)
                drawLayer(c, g, cl, 1f - (p - 0.6f) / 0.4f, mist)
            }
        }
    }

    private fun drawRoad(c: Canvas, g: Geometry) {
        val asph = U.mul(
            U.mix(U.rgb(0x4A4E57), U.rgb(0x14181F), sky.night * 0.9f),
            0.6f + 0.4f * sky.ar, 0.6f + 0.4f * sky.ag, 0.6f + 0.4f * sky.ab
        )
        val x0 = -W * 0.3f
        val x1 = W * 1.3f
        pFill.color = asph
        c.drawRect(x0, g.roadTop, x1, g.roadBot, pFill)
        val line = U.mix(U.rgb(0xEBE8D7), U.rgb(0x787D96), sky.night)
        pFill.color = U.withAlpha(line, 0.63f)
        c.drawRect(x0, g.roadTop + 3f, x1, g.roadTop + 5f, pFill)
        c.drawRect(x0, g.roadBot - 5f, x1, g.roadBot - 3f, pFill)

        val period = 100f * W / 720f
        val dash = 44f * W / 720f
        val off = U.fmod(distance, period.toDouble()).toFloat()
        val dy = g.yW + 0.006f * H
        pFill.color = U.withAlpha(line, 0.9f)
        var x = x0 - off - period
        while (x < x1) {
            c.drawRect(x, dy - 2f, x + dash, dy + 2f, pFill)
            x += period
        }
    }

    private fun drawForeground(c: Canvas, g: Geometry) {
        val cu = cur ?: return
        val color = U.mul(cu.def.fgColor, sky.ar, sky.ag, sky.ab)
        pFill.color = color
        c.drawRect(-W * 0.3f, g.roadBot, W * 1.3f, H * 2f, pFill)
        drawMask(c, cu.fg, g, distance * cu.fg.def.par, color, revealAlpha(7), blurAmount())
    }

    // ---- fireflies / bokeh ----------------------------------------------

    private fun drawFireflies(c: Canvas, g: Geometry) {
        val def = cur?.def ?: return
        if (!def.fireflies || sky.lamp < 0.05f) return
        val sc = W / 720f
        val groundY = U.lerp(g.yW, YWL * H, camera)
        val spread = U.lerp(1f, 1.5f, camera)
        val colr = U.rgb(0xD8F56B)
        for (i in 0 until ffN) {
            val x = ((ffX[i] * W + sin(time * 0.3f + ffP[i]) * 30f * sc + (distance * 0.02).toFloat()) % W + W) % W
            val y = groundY - (0.03f + 0.15f * ffY[i]) * H * spread + sin(time * 0.5f + ffP[i] * 2f) * 14f * sc
            val tw = 0.5f + 0.5f * sin(time * 1.7f + ffP[i] * 3f)
            val a = sky.lamp * (0.35f + 0.65f * tw)
            val r = U.lerp(2.0f * sc, (10f + 18f * ffR[i]) * sc, camera)
            pFill.color = U.withAlpha(colr, a * 0.10f)
            c.drawCircle(x, y, r * 2.2f, pFill)
            pFill.color = U.withAlpha(colr, a * 0.16f)
            c.drawCircle(x, y, r * 1.5f, pFill)
            pFill.color = U.withAlpha(colr, a * (0.60f - 0.38f * camera))
            c.drawCircle(x, y, r, pFill)
        }
    }

    // ---- neon clock -------------------------------------------------------

    private fun ringBump(k: Int): Float {
        if (flourishT < 0f) return 0f
        val local = flourishT - 0.15f * k
        if (local < 0f) return 0f
        return U.smooth(local / 0.12f) * (1f - U.smooth((local - 0.12f) / 0.75f))
    }

    private fun drawNeon(c: Canvas) {
        val m = neonCur ?: return
        if (m.text != wantText) return
        val a = neonQ * wakeFade
        if (a < 0.01f) return

        val lockVs = 0.80f * W / VanRenderer.LENGTH
        val gearTop = YWL * H + VanRenderer.GEAR_TOP * lockVs
        val digitsBottom = gearTop - 4f
        val top = digitsBottom - m.baseBottomPx
        val left = W / 2f - m.wPx / 2f
        dst.set(left, top, left + m.wPx, top + m.hPx)

        val glowC = U.mix(U.mix(GREEN_GLOW, BLUE_GLOW, blueMix), AMBER_GLOW, amberMix)
        val coreC = U.mix(U.mix(GREEN_CORE, BLUE_CORE, blueMix), AMBER_CORE, amberMix)

        // thin dark edge so the light neon stays readable on a bright sky
        val dk = sky.day * a
        if (dk > 0.02f) {
            pMask.color = U.withAlpha(DARK_EDGE, 0.22f * dk)
            c.drawBitmap(m.halo[0], null, dst, pMask)
            pMask.color = U.withAlpha(DARK_EDGE, 0.42f * dk)
            c.drawBitmap(m.glow[0], null, dst, pMask)
        }

        // the outermost bright ring breathes while charging
        var breathK = 0
        for (k in 1 until 4) if (ringReal[k] >= 0.9f) breathK = k
        val breathing = charging && park > 0.9f
        val breath = 0.78f + 0.22f * sin(time * 1.5f)

        for (k in 3 downTo 0) {
            var inten = ringDisp[k]
            if (k > 0) {
                val peak = if (ringReal[k] >= 0.5f) 1f else 0.6f
                inten = max(inten, ringBump(k) * peak)
            }
            if (breathing && k == breathK) inten *= breath
            inten *= a
            if (inten < 0.01f) continue
            pMask.color = U.withAlpha(glowC, 0.55f * inten)
            c.drawBitmap(m.halo[k], null, dst, pMask)
            pMask.color = U.withAlpha(glowC, 0.70f * inten)
            c.drawBitmap(m.glow[k], null, dst, pMask)
            pMask.color = U.withAlpha(coreC, inten)
            c.drawBitmap(m.core[k], null, dst, pMask)
        }

        // one light sweep over the digits at 100 %
        if (sweepT >= 0f) {
            val prog = sweepT / 0.9f
            val cx = left + m.wPx * (-0.15f + 1.30f * prog)
            val bw = m.wPx * 0.05f
            val prof = floatArrayOf(0.15f, 0.5f, 1f, 0.5f, 0.15f)
            for (j in 0 until 5) {
                val x0 = cx + (j - 2.5f) * bw
                c.save()
                c.clipRect(x0, top, x0 + bw, top + m.hPx)
                pMask.color = U.withAlpha(U.rgb(0xFFFFFF), 0.9f * prof[j] * a)
                for (k in 0 until 4) c.drawBitmap(m.core[k], null, dst, pMask)
                c.restore()
            }
        }

        // optional small battery percentage above the clock
        if (snap.showPercent) {
            val digitsTop = digitsBottom - Neon.digitHeightUnits() * m.unit
            val ty = digitsTop - (Neon.ringExtUnits() + 14f) * m.unit
            pText.textSize = 0.024f * H
            pText.color = U.withAlpha(glowC, 0.85f * a)
            c.drawText("$level%", W / 2f, ty, pText)
        }
    }

    // ---- weather ---------------------------------------------------------

    private fun drawWeather(c: Canvas) {
        if (wxI < 0.02f) return
        when (wxType) {
            1 -> drawRain(c)
            2 -> drawFog(c)
            3 -> drawSnowfall(c)
            else -> {
            }
        }
    }

    private fun drawRain(c: Canvas) {
        val n = (dropN * min(1f, wxI * 1.2f)).toInt()
        if (n <= 0) return
        val sc = W / 720f
        val k = 1f + 0.4f * camera
        for (i in 0 until n) {
            val y = (dropY[i] * H + time * 900f * dropV[i]) % H
            val x = ((dropX[i] * W - time * 140f * dropV[i]) % W + W) % W
            dropPts[i * 4] = x + 5f * sc * k
            dropPts[i * 4 + 1] = y - 24f * sc * k
            dropPts[i * 4 + 2] = x
            dropPts[i * 4 + 3] = y
        }
        pLine.color = U.withAlpha(0xDDE8F5, 0.32f * wxI)
        pLine.strokeWidth = 1.6f * sc * k
        c.drawLines(dropPts, 0, n * 4, pLine)
    }

    private fun drawSnowfall(c: Canvas) {
        val n = (flakeN * min(1f, wxI * 1.2f)).toInt()
        if (n <= 0) return
        val sc = W / 720f
        for (i in 0 until n) {
            val v = 0.6f + 0.8f * dropV[i % dropN]
            val y = (dropY[i % dropN] * H + time * 60f * v) % H
            val x = ((dropX[i % dropN] * W + sin(time * 0.8f + ffP[i % ffN]) * 18f * sc) % W + W) % W
            flakePts[i * 2] = x
            flakePts[i * 2 + 1] = y
        }
        pStar.color = U.withAlpha(0xFFFFFF, 0.85f * wxI)
        pStar.strokeWidth = 4.2f * sc * (1f + 0.5f * camera)
        c.drawPoints(flakePts, 0, n * 2, pStar)
        pStar.strokeWidth = 2.4f
    }

    private fun drawFog(c: Canvas) {
        val col = sky.hor
        val old = fogColor
        if (fogShader == null || abs(U.red(col) - U.red(old)) > 3 || abs(U.green(col) - U.green(old)) > 3 ||
            abs(U.blue(col) - U.blue(old)) > 3
        ) {
            fogColor = col
            fogShader = LinearGradient(
                0f, H * 0.38f, 0f, H * 0.92f,
                U.withAlpha(col, 0f), U.withAlpha(col, 0.88f), Shader.TileMode.CLAMP
            )
            pFog.shader = fogShader
        }
        pFog.alpha = (255f * wxI * (1f - 0.35f * camera)).toInt().coerceIn(0, 255)
        c.drawRect(0f, H * 0.38f, W, H, pFog)
    }

    private fun drawHint(c: Canvas) {
        if (!preview || demoState != 0 || hintT > 9f) return
        val a = U.smooth(hintT / 0.8f) * (1f - U.smooth((hintT - 7.5f) / 1.5f))
        if (a <= 0.01f) return
        pText.textSize = 0.019f * H
        pText.color = U.withAlpha(0xFFFFFF, 0.9f * a)
        c.drawText("Tap to preview lock screen", W / 2f, H * 0.12f, pText)
    }
}
