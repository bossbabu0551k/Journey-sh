package com.endlessroad.wallpaper

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import java.util.Random
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

/** Screen-derived layout numbers shared by the generator and the renderer. */
class Geometry(val W: Float, val H: Float, val roadFrac: Float) {
    val yW: Float = H * roadFrac            // where the wheels touch the road
    val roadTop: Float = yW - 0.020f * H
    val roadBot: Float = yW + 0.030f * H
    val yBottom: Float = roadTop + 4f       // bottom edge of every scenery layer
    val fgH: Float = (H - roadBot) + 0.05f * H
    val fgTop: Float = H - fgH
    val tile: Int = (W * 2f).toInt()
    val key: Int = (W.toInt() * 31 + H.toInt()) * 7 + (roadFrac * 1000f).toInt()
}

private val PINE_PTS = floatArrayOf(
    0f, 0f, 0.26f, 0.40f, 0.13f, 0.40f, 0.38f, 0.68f, 0.20f, 0.68f, 0.50f, 0.94f, 0.07f, 0.94f, 0.07f, 1.0f
)

/**
 * Drawing toolkit used by the biome recipes. Everything is drawn black into an ALPHA_8 bitmap
 * (a 1-byte-per-pixel mask) that gets tinted at draw time. (0,0) is the layer's top-left, `h` is
 * the ground line, `H` is the full screen height (sizes are fractions of it).
 */
class Gen(val c: Canvas, val w: Float, val h: Float, val H: Float) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clearP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    val lights = ArrayList<Float>()
    val windmills = ArrayList<Float>()

    init {
        fill.style = Paint.Style.FILL
        clearP.style = Paint.Style.FILL
        clearP.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        strokeP.style = Paint.Style.STROKE
        strokeP.strokeCap = Paint.Cap.ROUND
        strokeP.strokeJoin = Paint.Join.ROUND
    }

    // ---- basic shapes ----
    fun begin(x: Float, y: Float) {
        path.reset()
        path.moveTo(x, y)
    }

    fun to(x: Float, y: Float) {
        path.lineTo(x, y)
    }

    fun end() {
        path.close()
        c.drawPath(path, fill)
    }

    fun endClear() {
        path.close()
        c.drawPath(path, clearP)
    }

    fun rect(l: Float, t: Float, r: Float, b: Float) {
        c.drawRect(l, t, r, b, fill)
    }

    fun oval(l: Float, t: Float, r: Float, b: Float) {
        c.drawOval(l, t, r, b, fill)
    }

    fun line(x0: Float, y0: Float, x1: Float, y1: Float, wd: Float) {
        strokeP.strokeWidth = wd
        c.drawLine(x0, y0, x1, y1, strokeP)
    }

    /** Draws something at x and at x +- tile width so it wraps seamlessly. */
    fun rep(x: Float, fn: (Float) -> Unit) {
        fn(x)
        fn(x - w)
        fn(x + w)
    }

    // ---- terrain ----
    fun ground(fn: (Float) -> Float, step: Float = 6f) {
        begin(0f, h + 2f)
        var x = 0f
        while (x < w) {
            to(x, h - fn(x))
            x += step
        }
        to(w, h - fn(w - 0.01f))
        to(w, h + 2f)
        end()
    }

    /** Height function (px above the ground line) from periodic noise. */
    fun terr(
        seed: Int, cyc: Int, base: Float, amp: Float,
        oct: Int = 3, ridged: Boolean = false, power: Float = 1f
    ): (Float) -> Float {
        val t = Terrain(seed, cyc, oct)
        return { x: Float ->
            var n = if (ridged) t.ridged(x / w) else t.v(x / w)
            n = U.clamp01(n)
            if (power != 1f) n = Math.pow(n.toDouble(), power.toDouble()).toFloat()
            H * (base + amp * n)
        }
    }

    /** Plateau-ish function: zero in some places, steep up to `amp` in others (headlands). */
    fun shelf(seed: Int, cyc: Int, amp: Float, lo: Float, width: Float): (Float) -> Float {
        val t = Terrain(seed, cyc, 2)
        return { x: Float -> H * amp * U.smooth((t.v(x / w) - lo) / width) }
    }

    /** Stepped hillside (tea terraces). */
    fun terrace(seed: Int, cyc: Int, base: Float, amp: Float, k: Int): (Float) -> Float {
        val t = Terrain(seed, cyc, 2)
        return { x: Float ->
            val s = t.v(x / w) * k
            val fl = floor(s)
            val fr = s - fl
            H * (base + amp * (fl + U.smooth((fr - 0.55f) / 0.35f)) / k)
        }
    }

    /** Draws the ridge, then erases everything under a jagged line so only snow caps remain. */
    fun caps(fn: (Float) -> Float, capFrac: Float) {
        ground(fn, 4f)
        var mx = 0f
        var x = 0f
        while (x < w) {
            val v = fn(x)
            if (v > mx) mx = v
            x += 6f
        }
        val line = mx * capFrac
        begin(0f, h + 2f)
        x = 0f
        while (x < w) {
            val jag = (sin(x * 0.09f) + sin(x * 0.23f + 1.3f)) * H * 0.006f
            to(x, h - (line + jag))
            x += 5f
        }
        to(w, h - line)
        to(w, h + 2f)
        endClear()
    }

    // ---- trees ----
    fun pine(cx: Float, base: Float, hh: Float, ww: Float, snow: Boolean) {
        val top = base - hh
        if (snow) {
            snowCap(cx, top, hh, ww, 0.0f, 0.40f, 0.26f)
            snowCap(cx, top, hh, ww, 0.24f, 0.68f, 0.38f)
            snowCap(cx, top, hh, ww, 0.50f, 0.94f, 0.50f)
            return
        }
        val n = PINE_PTS.size / 2
        path.reset()
        path.moveTo(cx + ww * PINE_PTS[0], top + hh * PINE_PTS[1])
        for (i in 1 until n) {
            path.lineTo(cx + ww * PINE_PTS[2 * i], top + hh * PINE_PTS[2 * i + 1])
        }
        for (i in n - 1 downTo 0) {
            path.lineTo(cx - ww * PINE_PTS[2 * i], top + hh * PINE_PTS[2 * i + 1])
        }
        path.close()
        c.drawPath(path, fill)
    }

    private fun snowCap(cx: Float, top: Float, hh: Float, ww: Float, t0: Float, t1: Float, hw: Float) {
        val b = t0 + (t1 - t0) * 0.5f
        val half = ww * hw * 0.5f
        begin(cx, top + hh * t0)
        to(cx + half, top + hh * b)
        to(cx + half * 0.4f, top + hh * b - hh * 0.012f)
        to(cx - half * 0.4f, top + hh * b - hh * 0.012f)
        to(cx - half, top + hh * b)
        end()
    }

    fun roundTree(cx: Float, base: Float, hh: Float, ww: Float) {
        rect(cx - ww * 0.05f, base - hh * 0.40f, cx + ww * 0.05f, base)
        oval(cx - ww * 0.5f, base - hh, cx + ww * 0.5f, base - hh * 0.30f)
        oval(cx - ww * 0.34f, base - hh * 1.0f, cx + ww * 0.30f, base - hh * 0.55f)
    }

    private fun treeAt(k: Int, x: Float, b: Float, hh: Float, ww: Float, snow: Boolean) {
        if (k == 0) {
            pine(x, b, hh, ww, snow)
        } else if (!snow) {
            roundTree(x, b, hh, ww * 1.25f)
        }
    }

    /** kind: 0 pines, 1 round trees, 2 mix. The random sequence does not depend on `snow`. */
    fun treeRow(
        seed: Int, n: Int, hmin: Float, hmax: Float, kind: Int,
        baseFn: (Float) -> Float, snow: Boolean = false, wr: Float = 0.55f
    ) {
        val r = Random(seed.toLong())
        for (i in 0 until n) {
            val x = (i + r.nextFloat() * 0.8f) * w / n
            val hh = H * (hmin + (hmax - hmin) * r.nextFloat())
            val k = if (kind == 2) (if (r.nextFloat() < 0.65f) 0 else 1) else kind
            val ww = hh * wr * (0.9f + 0.2f * r.nextFloat())
            val b = h - baseFn(x) + hh * 0.02f
            rep(x) { xx -> treeAt(k, xx, b, hh, ww, snow) }
        }
    }

    fun bushes(seed: Int, n: Int, rmin: Float, rmax: Float, baseFn: (Float) -> Float) {
        val r = Random(seed.toLong())
        for (i in 0 until n) {
            val x = (i + r.nextFloat()) * w / n
            val rad = H * (rmin + (rmax - rmin) * r.nextFloat())
            val b = h - baseFn(x)
            rep(x) { xx -> oval(xx - rad * 1.2f, b - rad * 1.5f, xx + rad * 1.2f, b + rad * 0.4f) }
        }
    }

    // ---- props ----
    fun windmill(x: Float, base: Float, hh: Float) {
        val ww = hh * 0.16f
        begin(x - ww * 0.5f, base)
        to(x + ww * 0.5f, base)
        to(x + ww * 0.28f, base - hh)
        to(x - ww * 0.28f, base - hh)
        end()
        begin(x - ww * 0.42f, base - hh)
        to(x + ww * 0.42f, base - hh)
        to(x, base - hh - ww * 0.5f)
        end()
        windmills.add(x)
        windmills.add(base - hh - ww * 0.05f)
        windmills.add(hh * 0.62f)
    }

    fun barn(x: Float, base: Float, bw: Float, bh: Float) {
        begin(x - bw * 0.5f, base)
        to(x + bw * 0.5f, base)
        to(x + bw * 0.5f, base - bh * 0.62f)
        to(x + bw * 0.34f, base - bh * 0.86f)
        to(x, base - bh)
        to(x - bw * 0.34f, base - bh * 0.86f)
        to(x - bw * 0.5f, base - bh * 0.62f)
        end()
        val sx = x + bw * 0.78f
        rect(sx - bw * 0.16f, base - bh * 1.05f, sx + bw * 0.16f, base)
        oval(sx - bw * 0.16f, base - bh * 1.05f - bw * 0.16f, sx + bw * 0.16f, base - bh * 1.05f + bw * 0.16f)
    }

    fun cactus(x: Float, base: Float, hh: Float) {
        val t = hh * 0.13f
        rect(x - t / 2f, base - hh, x + t / 2f, base)
        oval(x - t / 2f, base - hh - t / 2f, x + t / 2f, base - hh + t / 2f)
        // left arm
        val lx = x - t * 1.7f
        val ly = base - hh * 0.45f
        rect(lx - t * 0.4f, ly - t * 0.4f, x, ly + t * 0.4f)
        rect(lx - t * 0.4f, ly - hh * 0.30f, lx + t * 0.4f, ly + t * 0.4f)
        oval(lx - t * 0.4f, ly - hh * 0.30f - t * 0.4f, lx + t * 0.4f, ly - hh * 0.30f + t * 0.4f)
        // right arm
        val rx = x + t * 1.7f
        val ry = base - hh * 0.62f
        rect(x, ry - t * 0.4f, rx + t * 0.4f, ry + t * 0.4f)
        rect(rx - t * 0.4f, ry - hh * 0.26f, rx + t * 0.4f, ry + t * 0.4f)
        oval(rx - t * 0.4f, ry - hh * 0.26f - t * 0.4f, rx + t * 0.4f, ry - hh * 0.26f + t * 0.4f)
    }

    fun butte(x: Float, base: Float, bw: Float, bh: Float) {
        begin(x - bw * 0.5f, base)
        to(x - bw * 0.40f, base - bh * 0.45f)
        to(x - bw * 0.46f, base - bh * 0.50f)
        to(x - bw * 0.30f, base - bh * 0.85f)
        to(x - bw * 0.34f, base - bh * 0.90f)
        to(x - bw * 0.22f, base - bh)
        to(x + bw * 0.24f, base - bh)
        to(x + bw * 0.34f, base - bh * 0.90f)
        to(x + bw * 0.30f, base - bh * 0.60f)
        to(x + bw * 0.45f, base - bh * 0.50f)
        to(x + bw * 0.50f, base)
        end()
    }

    fun lighthouse(x: Float, base: Float, hh: Float) {
        val ww = hh * 0.22f
        begin(x - ww * 0.5f, base)
        to(x + ww * 0.5f, base)
        to(x + ww * 0.34f, base - hh * 0.78f)
        to(x - ww * 0.34f, base - hh * 0.78f)
        end()
        rect(x - ww * 0.6f, base - hh * 0.80f, x + ww * 0.6f, base - hh * 0.76f)
        rect(x - ww * 0.28f, base - hh * 0.94f, x + ww * 0.28f, base - hh * 0.80f)
        begin(x - ww * 0.38f, base - hh * 0.94f)
        to(x + ww * 0.38f, base - hh * 0.94f)
        to(x, base - hh * 1.06f)
        end()
        lights.add(x)
        lights.add(base - hh * 0.87f)
    }

    fun palm(x: Float, base: Float, hh: Float, lean: Float) {
        var px = x
        var py = base
        for (i in 1..10) {
            val t = i / 10f
            val nx = x + lean * t * t * hh
            val ny = base - hh * t
            line(px, py, nx, ny, hh * 0.035f)
            px = nx
            py = ny
        }
        val angs = floatArrayOf(-170f, -140f, -110f, -70f, -40f, -10f, 20f, 160f)
        val len = hh * 0.40f
        for (a in angs) {
            val rad = Math.toRadians(a.toDouble())
            val dx = Math.cos(rad).toFloat()
            val dy = Math.sin(rad).toFloat()
            val mx = px + dx * len * 0.5f
            val my = py + dy * len * 0.5f - len * 0.12f
            val tx = px + dx * len
            val ty = py + dy * len * 0.4f + len * 0.30f
            path.reset()
            path.moveTo(px, py)
            path.quadTo(mx, my - len * 0.07f, tx, ty)
            path.quadTo(mx, my + len * 0.09f, px, py)
            path.close()
            c.drawPath(path, fill)
        }
    }

    fun umbrellaTree(x: Float, base: Float, hh: Float) {
        rect(x - hh * 0.018f, base - hh * 0.8f, x + hh * 0.018f, base)
        oval(x - hh * 0.42f, base - hh * 1.0f, x + hh * 0.42f, base - hh * 0.72f)
        oval(x - hh * 0.30f, base - hh * 1.08f, x + hh * 0.30f, base - hh * 0.82f)
    }

    fun hut(x: Float, base: Float, hw: Float, hh: Float) {
        rect(x - hw * 0.45f, base - hh * 0.55f, x - hw * 0.40f, base)
        rect(x + hw * 0.40f, base - hh * 0.55f, x + hw * 0.45f, base)
        begin(x - hw * 0.6f, base - hh * 0.5f)
        to(x + hw * 0.6f, base - hh * 0.5f)
        to(x + hw * 0.38f, base - hh * 0.85f)
        to(x - hw * 0.38f, base - hh * 0.85f)
        end()
        rect(x - hw * 0.4f, base - hh * 0.18f, x + hw * 0.4f, base - hh * 0.10f)
        lights.add(x)
        lights.add(base - hh * 0.45f)
    }

    /** Telephone poles with sagging wires, plus street lamps (their lights are recorded). */
    fun poles() {
        val ph = H * 0.115f
        val x1 = w * 0.12f
        val x2 = w * 0.62f
        val base = h - 2f
        val xs = floatArrayOf(x1, x2)
        for (x in xs) {
            rep(x) { xx ->
                rect(xx - 2f, base - ph, xx + 2f, base)
                rect(xx - 14f, base - ph + 6f, xx + 14f, base - ph + 9f)
                rect(xx - 10f, base - ph + 20f, xx + 10f, base - ph + 22f)
            }
        }
        val spansA = floatArrayOf(x1, x2, x2, x1 + w)
        val offs = floatArrayOf(-w, 0f, w)
        val dys = floatArrayOf(7.5f, 21f)
        strokeP.strokeWidth = 1.6f
        for (s in 0 until 2) {
            val a = spansA[s * 2]
            val b = spansA[s * 2 + 1]
            for (off in offs) {
                for (dy in dys) {
                    val y0 = base - ph + dy
                    path.reset()
                    path.moveTo(a + off, y0)
                    path.quadTo((a + b) / 2f + off, y0 + 40f, b + off, y0)
                    c.drawPath(path, strokeP)
                }
            }
        }
        val lh = H * 0.085f
        val lamps = floatArrayOf(w * 0.37f, w * 0.87f)
        for (x in lamps) {
            rep(x) { xx ->
                rect(xx - 1.8f, base - lh, xx + 1.8f, base)
                line(xx, base - lh, xx + 16f, base - lh - 3f, 3.2f)
                oval(xx + 10f, base - lh - 1f, xx + 24f, base - lh + 5f)
            }
            lights.add(x + 17f)
            lights.add(base - lh + 4f)
        }
    }

    fun guardrail() {
        val base = h - 2f
        val y = base - H * 0.012f
        rect(0f, y - 3f, w, y)
        rect(0f, y + 8f, w, y + 10f)
        var x = 0f
        while (x < w) {
            rect(x - 1.5f, y - 3f, x + 1.5f, base - 2f)
            x += 36f
        }
    }

    /** Foreground verge below the road. kind: 0 grass, 1 snow, 2 sand. */
    fun fgLayer(kind: Int, seed: Int) {
        val r = Random(seed.toLong())
        val t = Terrain(seed, 5, 2)
        val y0 = h * 0.40f
        val fn = { x: Float -> H * (0.004f + 0.012f * t.v(x / w)) }
        begin(0f, h)
        var x = 0f
        while (x < w) {
            to(x, y0 - fn(x))
            x += 5f
        }
        to(w, y0 - fn(w - 0.01f))
        to(w, h)
        end()
        if (kind == 0) {
            val n = (w / 7f).toInt()
            for (i in 0 until n) {
                val gx = r.nextFloat() * w
                val hh = H * (0.008f + 0.02f * r.nextFloat())
                val b = y0 - fn(gx) + 2f
                val lean = (r.nextFloat() - 0.5f) * 8f
                rep(gx) { xx ->
                    begin(xx - 2.2f, b)
                    to(xx + lean, b - hh)
                    to(xx + 2.2f, b)
                    end()
                }
            }
        } else {
            val n = if (kind == 1) 8 else 10
            val k = if (kind == 1) 2.2f else 2.8f
            for (i in 0 until n) {
                val gx = r.nextFloat() * w
                val rad = H * (0.006f + 0.008f * r.nextFloat())
                rep(gx) { xx -> oval(xx - rad * k, y0 - rad * 0.5f - fn(xx), xx + rad * k, y0 + rad) }
            }
        }
    }
}

class LayerDef(
    /** Scroll speed relative to the road (1.0). */
    val par: Float,
    /** Height of the layer bitmap as a fraction of the screen height. */
    val hf: Float,
    val color: Int,
    /** 0 = full colour, 1 = fades into the horizon colour. */
    val haze: Float,
    val gen: Gen.() -> Unit
)

class BiomeDef(
    val id: Int,
    val name: String,
    val layers: Array<LayerDef>,
    val fgColor: Int,
    /** 0 grass, 1 snow, 2 sand */
    val fgKind: Int,
    val fireflies: Boolean,
    val aurora: Boolean,
    val snowy: Boolean
)

/** One generated scenery layer: sharp mask, a small "soft" mask (upscaled = blur) and prop data. */
class LayerAsset(
    val def: LayerDef,
    val sharp: Bitmap,
    val soft: Bitmap,
    val top: Float,
    val lights: FloatArray,
    val windmills: FloatArray
)

class BiomeAssets(
    val def: BiomeDef,
    val layers: Array<LayerAsset>,
    val fg: LayerAsset,
    val geoKey: Int
)

object Biomes {
    const val COUNT = 7
    private const val SOFT = 6

    private val HAZE = floatArrayOf(0.80f, 0.68f, 0.56f, 0.44f, 0.32f, 0.20f, 0.09f, 0.0f)
    private val PAR = floatArrayOf(0.012f, 0.025f, 0.05f, 0.09f, 0.16f, 0.28f, 0.5f, 0.85f)

    private fun layers(cols: IntArray, hf: FloatArray, par: FloatArray, gens: Array<Gen.() -> Unit>): Array<LayerDef> =
        Array(8) { i -> LayerDef(par[i], hf[i], U.rgb(cols[i]), HAZE[i], gens[i]) }

    fun name(id: Int): String = when (id) {
        0 -> "Woods"
        1 -> "Cornfields"
        2 -> "Desert"
        3 -> "Mountains"
        4 -> "Coast"
        5 -> "Snow"
        else -> "Tea gardens"
    }

    fun def(id: Int): BiomeDef = when (id) {
        0 -> woods()
        1 -> fields()
        2 -> desert()
        3 -> mountains()
        4 -> coast()
        5 -> snow()
        else -> tea()
    }

    private fun woods(): BiomeDef {
        val cols = intArrayOf(0xA9C0D4, 0x8FB3B0, 0x6E9F82, 0x548C69, 0x3F7656, 0x2F6045, 0x1F4733, 0x2B313B)
        val hf = floatArrayOf(0.28f, 0.22f, 0.16f, 0.17f, 0.20f, 0.08f, 0.30f, 0.17f)
        val gens = arrayOf<Gen.() -> Unit>(
            { ground(terr(11, 3, 0.07f, 0.21f)) },
            { ground(terr(12, 4, 0.05f, 0.15f)) },
            {
                val b = terr(13, 3, 0.02f, 0.02f, 2)
                ground(b)
                treeRow(5, 38, 0.05f, 0.085f, 0, b)
            },
            {
                val b = terr(14, 3, 0.015f, 0.02f, 2)
                ground(b)
                treeRow(6, 24, 0.07f, 0.115f, 0, b)
            },
            {
                val b = terr(15, 3, 0.01f, 0.02f, 2)
                ground(b)
                treeRow(7, 15, 0.09f, 0.15f, 2, b)
            },
            {
                val b = terr(16, 4, 0.008f, 0.014f, 2)
                ground(b)
                bushes(8, 20, 0.012f, 0.024f, b)
            },
            { treeRow(9, 6, 0.17f, 0.27f, 0, { _ -> 0f }, wr = 0.5f) },
            { poles() }
        )
        return BiomeDef(0, "Woods", layers(cols, hf, PAR, gens), U.rgb(0x244E37), 0, true, false, false)
    }

    private fun fields(): BiomeDef {
        val cols = intArrayOf(0xAEBBC8, 0xC3C98F, 0xDDBB62, 0x86A04F, 0x9A5A32, 0xC9962E, 0x8D6428, 0x2B313B)
        val hf = floatArrayOf(0.22f, 0.20f, 0.26f, 0.12f, 0.14f, 0.12f, 0.16f, 0.17f)
        val gens = arrayOf<Gen.() -> Unit>(
            { ground(terr(21, 2, 0.05f, 0.16f)) },
            { ground(terr(22, 3, 0.04f, 0.14f)) },
            {
                val f = terr(23, 2, 0.03f, 0.10f)
                ground(f)
                val x = w * 0.62f
                windmill(x, h - f(x) + 3f, H * 0.11f)
            },
            {
                val b = terr(24, 3, 0.01f, 0.02f, 2)
                ground(b)
                treeRow(25, 22, 0.035f, 0.06f, 1, b)
            },
            {
                val b = terr(26, 3, 0.012f, 0.02f, 2)
                ground(b)
                val x1 = w * 0.28f
                val x2 = w * 0.80f
                barn(x1, h - b(x1) + 2f, H * 0.075f, H * 0.06f)
                barn(x2, h - b(x2) + 2f, H * 0.075f, H * 0.06f)
            },
            {
                val b = terr(27, 4, 0.006f, 0.01f, 2)
                ground(b)
                val r = Random(3L)
                val n = (w / 6f).toInt()
                for (i in 0 until n) {
                    val x = r.nextFloat() * w
                    val hh = H * (0.04f + 0.04f * r.nextFloat())
                    val bb = h - b(x) + 2f
                    val lean = (r.nextFloat() - 0.5f) * 8f
                    rep(x) { xx ->
                        begin(xx - 1.8f, bb)
                        to(xx + lean, bb - hh)
                        to(xx + 1.8f, bb)
                        end()
                        begin(xx, bb - hh * 0.5f)
                        to(xx + 15f, bb - hh * 0.66f)
                        to(xx + 1f, bb - hh * 0.40f)
                        end()
                    }
                }
            },
            {
                val b = terr(28, 3, 0.004f, 0.008f, 2)
                ground(b)
                val r = Random(4L)
                for (i in 0 until 5) {
                    val x = (i + 0.5f) * w / 5f + (r.nextFloat() - 0.5f) * 40f
                    rep(x) { xx -> oval(xx - H * 0.02f, h - b(xx) - H * 0.03f, xx + H * 0.02f, h - b(xx) + 4f) }
                }
                val sx = w * 0.45f
                val bb = h - b(sx)
                line(sx, bb, sx, bb - H * 0.06f, 3f)
                line(sx - H * 0.03f, bb - H * 0.045f, sx + H * 0.03f, bb - H * 0.045f, 3f)
                oval(sx - 8f, bb - H * 0.075f, sx + 8f, bb - H * 0.055f)
                begin(sx - 13f, bb - H * 0.066f)
                to(sx + 13f, bb - H * 0.066f)
                to(sx, bb - H * 0.09f)
                end()
                var fx = 0f
                while (fx < w) {
                    rect(fx - 1.5f, bb - H * 0.028f, fx + 1.5f, bb + 4f)
                    fx += 54f
                }
                rect(0f, bb - H * 0.022f, w, bb - H * 0.019f)
            },
            { poles() }
        )
        return BiomeDef(1, "Cornfields", layers(cols, hf, PAR, gens), U.rgb(0x8F7A2E), 0, true, false, false)
    }

    private fun desert(): BiomeDef {
        val cols = intArrayOf(0xDDB79B, 0xEAC38E, 0xCF8B62, 0xE0A867, 0xB26540, 0xD49B58, 0x6D7F4B, 0x3A332E)
        val hf = floatArrayOf(0.26f, 0.14f, 0.24f, 0.15f, 0.12f, 0.06f, 0.28f, 0.17f)
        val gens = arrayOf<Gen.() -> Unit>(
            {
                val t = Terrain(31, 3, 2)
                ground({ x: Float ->
                    val n = t.v(x / w)
                    H * (0.04f + 0.09f * U.smooth((n - 0.45f) / 0.05f) + 0.09f * U.smooth((n - 0.60f) / 0.05f))
                }, 4f)
            },
            { ground(terr(32, 3, 0.03f, 0.09f, 2)) },
            {
                val b = terr(33, 3, 0.02f, 0.04f, 2)
                ground(b)
                butte(w * 0.20f, h - b(w * 0.20f) + 3f, H * 0.10f, H * 0.15f)
                butte(w * 0.55f, h - b(w * 0.55f) + 3f, H * 0.075f, H * 0.12f)
                butte(w * 0.85f, h - b(w * 0.85f) + 3f, H * 0.12f, H * 0.17f)
            },
            { ground(terr(34, 4, 0.02f, 0.10f, 2)) },
            {
                val b = terr(35, 4, 0.01f, 0.03f, 2)
                ground(b)
                val r = Random(9L)
                for (i in 0 until 7) {
                    val x = r.nextFloat() * w
                    val s = H * (0.012f + 0.02f * r.nextFloat())
                    val bb = h - b(x)
                    rep(x) { xx ->
                        begin(xx - s * 1.6f, bb + 2f)
                        to(xx - s * 0.8f, bb - s)
                        to(xx + s * 0.5f, bb - s * 1.1f)
                        to(xx + s * 1.5f, bb + 2f)
                        end()
                    }
                }
                for (i in 0 until 6) {
                    val x = r.nextFloat() * w
                    val s = H * 0.012f
                    val bb = h - b(x)
                    rep(x) { xx -> oval(xx - s, bb - s * 1.8f, xx + s, bb + 2f) }
                }
            },
            { ground(terr(36, 5, 0.01f, 0.03f, 2)) },
            {
                val xs = floatArrayOf(w * 0.12f, w * 0.50f, w * 0.78f)
                for (i in 0 until 3) {
                    val hh = H * (0.11f + 0.04f * ((i * 7) % 3) / 2f)
                    rep(xs[i]) { xx -> cactus(xx, h + 2f, hh) }
                }
            },
            { poles() }
        )
        return BiomeDef(2, "Desert", layers(cols, hf, PAR, gens), U.rgb(0xB9803F), 2, false, false, false)
    }

    private fun mountains(): BiomeDef {
        val cols = intArrayOf(0x93A8C6, 0xF2F6FC, 0x6F8AA2, 0x4C7566, 0x356150, 0x2C5444, 0x1D3C31, 0x2E333B)
        val hf = floatArrayOf(0.36f, 0.36f, 0.26f, 0.22f, 0.18f, 0.08f, 0.30f, 0.17f)
        val par = floatArrayOf(0.012f, 0.012f, 0.05f, 0.09f, 0.16f, 0.28f, 0.5f, 0.85f)
        val gens = arrayOf<Gen.() -> Unit>(
            { ground(terr(41, 3, 0.02f, 0.32f, 3, true, 1.15f)) },
            { caps(terr(41, 3, 0.02f, 0.32f, 3, true, 1.15f), 0.70f) },
            { ground(terr(42, 4, 0.02f, 0.22f, 3, true, 1.0f)) },
            {
                val b = terr(43, 3, 0.03f, 0.10f, 2)
                ground(b)
                treeRow(44, 34, 0.04f, 0.07f, 0, b)
            },
            {
                val b = terr(45, 3, 0.01f, 0.03f, 2)
                ground(b)
                treeRow(46, 18, 0.08f, 0.13f, 0, b)
            },
            {
                val b = terr(47, 4, 0.008f, 0.014f, 2)
                ground(b)
                bushes(48, 16, 0.012f, 0.022f, b)
            },
            { treeRow(49, 5, 0.18f, 0.28f, 0, { _ -> 0f }, wr = 0.5f) },
            {
                poles()
                guardrail()
            }
        )
        return BiomeDef(3, "Mountains", layers(cols, hf, par, gens), U.rgb(0x2A4F3E), 0, false, false, false)
    }

    private fun coast(): BiomeDef {
        val cols = intArrayOf(0x94B9CC, 0x58AFD6, 0xD4EEF7, 0x8E7B68, 0x6C9F5C, 0xE5D2A0, 0x2E7550, 0x313740)
        val hf = floatArrayOf(0.20f, 0.14f, 0.14f, 0.30f, 0.30f, 0.07f, 0.27f, 0.17f)
        val par = floatArrayOf(0.012f, 0.025f, 0.025f, 0.09f, 0.09f, 0.28f, 0.5f, 0.85f)
        val gens = arrayOf<Gen.() -> Unit>(
            { ground(terr(51, 4, 0.02f, 0.12f, 2, true)) },
            { ground({ _ -> H * 0.14f }) },
            {
                val r = Random(7L)
                for (i in 0 until 90) {
                    val x = r.nextFloat() * w
                    val y = h * (0.12f + 0.86f * Math.pow(r.nextFloat().toDouble(), 0.8).toFloat())
                    val wd = 14f + 50f * r.nextFloat() * (y / h + 0.3f)
                    rep(x) { xx -> rect(xx, y, xx + wd, y + 2.2f) }
                }
            },
            {
                val f = shelf(52, 2, 0.22f, 0.46f, 0.22f)
                ground(f)
                var xm = 0f
                var best = -1f
                var x = 0f
                while (x < w) {
                    val v = f(x)
                    if (v > best) {
                        best = v
                        xm = x
                    }
                    x += 6f
                }
                lighthouse(xm, h - f(xm) + 4f, H * 0.10f)
            },
            {
                // grassy top of the same headland: draw it, then erase all but a thin band
                val f = shelf(52, 2, 0.22f, 0.46f, 0.22f)
                ground(f)
                begin(0f, h + 2f)
                var x = 0f
                while (x < w) {
                    to(x, h - f(x) + H * 0.016f)
                    x += 6f
                }
                to(w, h - f(w - 0.01f) + H * 0.016f)
                to(w, h + 2f)
                endClear()
            },
            { ground(terr(53, 4, 0.012f, 0.03f, 2)) },
            {
                palm(w * 0.18f, h + 2f, H * 0.15f, 0.06f)
                palm(w * 0.55f, h + 2f, H * 0.12f, -0.08f)
                palm(w * 0.83f, h + 2f, H * 0.14f, 0.05f)
            },
            {
                poles()
                guardrail()
            }
        )
        return BiomeDef(4, "Coast", layers(cols, hf, par, gens), U.rgb(0xC9B27A), 2, false, false, false)
    }

    private fun snow(): BiomeDef {
        val cols = intArrayOf(0xB9C9E0, 0xFAFCFF, 0xDCE7F4, 0x3B6A62, 0xF5F9FF, 0xEDF4FC, 0x244A45, 0x3A4350)
        val hf = floatArrayOf(0.36f, 0.36f, 0.22f, 0.20f, 0.20f, 0.08f, 0.30f, 0.17f)
        val par = floatArrayOf(0.012f, 0.012f, 0.05f, 0.09f, 0.09f, 0.28f, 0.5f, 0.85f)
        val gens = arrayOf<Gen.() -> Unit>(
            { ground(terr(61, 3, 0.02f, 0.32f, 3, true, 1.15f)) },
            { caps(terr(61, 3, 0.02f, 0.32f, 3, true, 1.15f), 0.66f) },
            { ground(terr(62, 3, 0.03f, 0.17f, 2)) },
            {
                val b = terr(63, 3, 0.015f, 0.03f, 2)
                ground(b)
                treeRow(64, 30, 0.06f, 0.10f, 0, b)
            },
            {
                val b = terr(63, 3, 0.015f, 0.03f, 2)
                treeRow(64, 30, 0.06f, 0.10f, 0, b, snow = true)
            },
            { ground(terr(65, 4, 0.01f, 0.03f, 2)) },
            { treeRow(66, 5, 0.17f, 0.26f, 0, { _ -> 0f }, wr = 0.5f) },
            { poles() }
        )
        return BiomeDef(5, "Snow", layers(cols, hf, par, gens), U.rgb(0xE9F1FA), 1, false, true, true)
    }

    private fun tea(): BiomeDef {
        val cols = intArrayOf(0xA9C2B3, 0x8CB689, 0x7FB85E, 0x5F9E49, 0x355F40, 0x3E7E3F, 0x6B5338, 0x2C333B)
        val hf = floatArrayOf(0.28f, 0.24f, 0.22f, 0.17f, 0.26f, 0.07f, 0.20f, 0.17f)
        val gens = arrayOf<Gen.() -> Unit>(
            { ground(terr(71, 3, 0.05f, 0.22f)) },
            { ground(terr(72, 4, 0.04f, 0.18f)) },
            { ground(terrace(73, 2, 0.02f, 0.17f, 5), 4f) },
            { ground(terrace(74, 3, 0.015f, 0.12f, 4), 4f) },
            {
                val r = Random(13L)
                for (i in 0 until 8) {
                    val x = (i + r.nextFloat() * 0.7f) * w / 8f
                    val hh = H * (0.12f + 0.07f * r.nextFloat())
                    rep(x) { xx -> umbrellaTree(xx, h + 2f, hh) }
                }
            },
            {
                val b = terr(75, 4, 0.008f, 0.012f, 2)
                ground(b)
                val r = Random(14L)
                for (i in 0 until 60) {
                    val x = (i + r.nextFloat()) * w / 60f
                    val rad = H * 0.016f
                    rep(x) { xx -> oval(xx - rad * 1.5f, h - b(xx) - rad * 1.6f, xx + rad * 1.5f, h - b(xx) + 3f) }
                }
            },
            {
                hut(w * 0.35f, h + 2f, H * 0.09f, H * 0.08f)
                val bx = floatArrayOf(w * 0.75f, w * 0.80f, w * 0.84f)
                for (x in bx) {
                    line(x, h + 2f, x + 6f, h - H * 0.17f, H * 0.006f)
                    line(x, h - H * 0.06f, x - 14f, h - H * 0.09f, 2f)
                }
            },
            { poles() }
        )
        return BiomeDef(6, "Tea gardens", layers(cols, hf, PAR, gens), U.rgb(0x2F6A3A), 0, true, false, false)
    }

    // ------------------------------------------------------------------
    // Bitmap generation (runs on a background thread)
    // ------------------------------------------------------------------

    private fun makeLayer(ld: LayerDef, geo: Geometry, hPx: Int, top: Float): LayerAsset {
        val t = geo.tile
        val sharp = Bitmap.createBitmap(t, hPx, Bitmap.Config.ALPHA_8)
        val g1 = Gen(Canvas(sharp), t.toFloat(), hPx.toFloat(), geo.H)
        ld.gen.invoke(g1)

        val sw = max(1, (t + SOFT - 1) / SOFT)
        val sh = max(1, (hPx + SOFT - 1) / SOFT)
        val soft = Bitmap.createBitmap(sw, sh, Bitmap.Config.ALPHA_8)
        val sc = Canvas(soft)
        sc.scale(sw.toFloat() / t, sh.toFloat() / hPx)
        val g2 = Gen(sc, t.toFloat(), hPx.toFloat(), geo.H)
        ld.gen.invoke(g2)

        return LayerAsset(ld, sharp, soft, top, g1.lights.toFloatArray(), g1.windmills.toFloatArray())
    }

    fun build(id: Int, geo: Geometry): BiomeAssets {
        val def = def(id)
        val layers = Array(8) { i ->
            val ld = def.layers[i]
            val hPx = max(8, (ld.hf * geo.H).toInt())
            makeLayer(ld, geo, hPx, geo.yBottom - hPx)
        }
        val kind = def.fgKind
        val fgDef = LayerDef(1.30f, 0f, def.fgColor, 0f, { fgLayer(kind, 99) })
        val fg = makeLayer(fgDef, geo, max(8, geo.fgH.toInt()), geo.fgTop)
        return BiomeAssets(def, layers, fg, geo.key)
    }
}
